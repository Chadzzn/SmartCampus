<?php
// ============================================================
// middleware/auth.php — Vérification des droits
// Version adaptée pour MAMP + React en cross-origin.
// Au lieu des sessions PHP (bloquées par CORS), on utilise
// des headers HTTP envoyés par le frontend à chaque requête.
// ============================================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Credentials: false');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-User-Role, X-User-Id');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ============================================================
// Récupération du rôle et de l'ID depuis les headers HTTP
// Le frontend les envoie via axios.interceptors.request
// ============================================================
function getUserFromHeaders() {
    return [
        // getallheaders() lit tous les headers HTTP de la requête
        'role' => getallheaders()['X-User-Role'] ?? null,
        'id'   => getallheaders()['X-User-Id']   ?? null,
    ];
}

// ============================================================
// Fonction : requireAuth()
// Vérifie qu'un header X-User-Role est présent
// ============================================================
function requireAuth() {
    $user = getUserFromHeaders();
    if (!$user['role']) {
        http_response_code(401);
        echo json_encode(['error' => 'Non authentifié. Veuillez vous connecter.']);
        exit;
    }
}

// ============================================================
// Fonction : requireRole($roles)
// Vérifie que le rôle envoyé dans les headers est autorisé
// ============================================================
function requireRole($roles) {
    requireAuth();

    $user = getUserFromHeaders();

    if (!is_array($roles)) {
        $roles = [$roles];
    }

    if (!in_array($user['role'], $roles)) {
        http_response_code(403);
        echo json_encode(['error' => 'Accès interdit. Rôle insuffisant.']);
        exit;
    }
}

// ============================================================
// Fonction : getCurrentUser()
// Retourne les infos de l'utilisateur depuis les headers
// ============================================================
function getCurrentUser() {
    return getUserFromHeaders();
}
