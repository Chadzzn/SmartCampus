<?php
// ============================================================
// config/db.php — Connexion à la base de données MySQL
// Ce fichier est inclus dans tous les fichiers PHP qui ont
// besoin d'accéder à la base de données.
// ============================================================

// --- Paramètres de connexion ---
// Modifie ces valeurs selon ton environnement (XAMPP, WAMP, etc.)
define('DB_HOST', 'localhost');
define('DB_NAME', 'smartcampus');
define('DB_USER', 'root');
define('DB_PASS', 'root');          // Mot de passe MySQL (vide par défaut sur XAMPP)
define('DB_CHARSET', 'utf8mb4');

// --- Création de la connexion PDO ---
// PDO est une façon sécurisée et moderne de se connecter à MySQL en PHP.
// Elle protège notamment contre les injections SQL grâce aux requêtes préparées.
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER,
        DB_PASS,
        [
            // PDO lance une exception si une requête SQL échoue
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            // Les résultats sont retournés sous forme de tableaux associatifs
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            // Désactive l'émulation des requêtes préparées (plus sécurisé)
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    // En cas d'erreur de connexion, on arrête tout et on affiche le message
    http_response_code(500);
    echo json_encode(['error' => 'Erreur de connexion à la base de données : ' . $e->getMessage()]);
    exit;
}
