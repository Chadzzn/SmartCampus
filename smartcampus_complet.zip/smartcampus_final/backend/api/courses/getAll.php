<?php
// ============================================================
// api/courses/getAll.php — Liste tous les cours
// Méthode : GET
// Accès : tous les utilisateurs connectés
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireAuth();

// On joint la table enseignants et users pour avoir le nom de l'enseignant
// On compte aussi le nombre d'étudiants inscrits à chaque cours
$stmt = $pdo->query("
    SELECT
        c.id,
        c.code,
        c.nom,
        c.description,
        c.credits,
        c.capacite_max,
        c.semestre,
        c.promotion,
        CONCAT(u.prenom, ' ', u.nom) as enseignant_nom,
        c.enseignant_id,
        COUNT(i.id) as nb_inscrits   -- nombre d'étudiants actuellement inscrits
    FROM cours c
    LEFT JOIN enseignants en ON en.id = c.enseignant_id
    LEFT JOIN users u ON u.id = en.user_id
    LEFT JOIN inscriptions i ON i.cours_id = c.id AND i.statut = 'actif'
    GROUP BY c.id
    ORDER BY c.semestre, c.nom
");

echo json_encode($stmt->fetchAll());
