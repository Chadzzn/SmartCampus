<?php
// ============================================================
// api/courses/update.php — Modifier un cours
// Méthode : PUT | URL param : ?id=X | Accès : admin
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405); echo json_encode(['error' => 'Méthode non autorisée']); exit;
}

$id   = $_GET['id'] ?? null;
$data = json_decode(file_get_contents('php://input'), true);

$stmt = $pdo->prepare("SELECT id FROM cours WHERE id = ?");
$stmt->execute([$id]);
if (!$stmt->fetch()) {
    http_response_code(404); echo json_encode(['error' => 'Cours introuvable']); exit;
}

$stmt = $pdo->prepare("
    UPDATE cours SET nom=?, description=?, credits=?, capacite_max=?, semestre=?, promotion=?, enseignant_id=?
    WHERE id=?
");
$stmt->execute([
    $data['nom'],
    $data['description']   ?? null,
    $data['credits']       ?? 3,
    $data['capacite_max']  ?? 30,
    $data['semestre']      ?? null,
    $data['promotion']     ?? null,
    $data['enseignant_id'] ?? null,
    $id
]);

echo json_encode(['message' => 'Cours mis à jour avec succès']);
