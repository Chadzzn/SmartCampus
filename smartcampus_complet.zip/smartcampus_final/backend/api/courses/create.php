<?php
// ============================================================
// api/courses/create.php — Créer un cours
// Méthode : POST | Accès : admin uniquement
// Body JSON : { code, nom, description, credits, capacite_max, semestre, promotion, enseignant_id }
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); echo json_encode(['error' => 'Méthode non autorisée']); exit;
}

$data = json_decode(file_get_contents('php://input'), true);

foreach (['code','nom'] as $field) {
    if (empty($data[$field])) {
        http_response_code(400); echo json_encode(['error' => "Champ '$field' obligatoire"]); exit;
    }
}

// Vérification que le code cours est unique
$stmt = $pdo->prepare("SELECT id FROM cours WHERE code = ?");
$stmt->execute([$data['code']]);
if ($stmt->fetch()) {
    http_response_code(409); echo json_encode(['error' => 'Ce code cours existe déjà']); exit;
}

$stmt = $pdo->prepare("
    INSERT INTO cours (code, nom, description, credits, capacite_max, semestre, promotion, enseignant_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
");
$stmt->execute([
    $data['code'],
    $data['nom'],
    $data['description'] ?? null,
    $data['credits']      ?? 3,
    $data['capacite_max'] ?? 30,
    $data['semestre']     ?? null,
    $data['promotion']    ?? null,
    $data['enseignant_id'] ?? null,
]);

http_response_code(201);
echo json_encode(['message' => 'Cours créé avec succès', 'id' => $pdo->lastInsertId()]);
