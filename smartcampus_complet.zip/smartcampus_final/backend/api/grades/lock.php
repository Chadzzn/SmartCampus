<?php
// ============================================================
// api/grades/lock.php — Verrouiller toutes les notes d'un cours
// Méthode : POST | Accès : admin uniquement
// Body JSON : { cours_id }
// Une fois verrouillées, les notes ne peuvent plus être modifiées
// (sauf par l'admin via un déverrouillage explicite)
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); echo json_encode(['error' => 'Méthode non autorisée']); exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$coursId = $data['cours_id'] ?? null;

if (!$coursId) { http_response_code(400); echo json_encode(['error' => 'cours_id requis']); exit; }

// Verrouillage de toutes les notes du cours
$stmt = $pdo->prepare("UPDATE notes SET verrouille = TRUE WHERE cours_id = ?");
$stmt->execute([$coursId]);

echo json_encode(['message' => 'Notes verrouillées avec succès', 'nb_verrouillees' => $stmt->rowCount()]);
