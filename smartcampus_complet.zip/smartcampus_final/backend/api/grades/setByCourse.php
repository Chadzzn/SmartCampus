<?php
// ============================================================
// api/grades/setByCourse.php — Saisir ou modifier une note
// Méthode : POST | Accès : enseignant ou admin
// Body JSON : { etudiant_id, cours_id, note, commentaire }
//
// RÈGLE MÉTIER : Si la note est verrouillée (verrouille = TRUE),
// seul l'admin peut encore la modifier.
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

// Seuls les enseignants et admins peuvent saisir des notes
requireRole(['enseignant', 'admin']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Méthode non autorisée']);
    exit;
}

// Lecture du corps JSON de la requête
$data = json_decode(file_get_contents('php://input'), true);

// Vérification des champs obligatoires
if (!isset($data['etudiant_id'], $data['cours_id'], $data['note'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Champs manquants : etudiant_id, cours_id et note sont requis']);
    exit;
}

// Validation : la note doit être entre 0 et 20
if ($data['note'] < 0 || $data['note'] > 20) {
    http_response_code(400);
    echo json_encode(['error' => 'La note doit être comprise entre 0 et 20']);
    exit;
}

// Récupération du rôle depuis les headers HTTP (et non depuis $_SESSION)
// C'est le middleware auth.php qui fournit getCurrentUser()
$currentUser = getCurrentUser();

// Vérifier si une note existe déjà pour cet étudiant dans ce cours
$stmt = $pdo->prepare("SELECT id, verrouille FROM notes WHERE etudiant_id = ? AND cours_id = ?");
$stmt->execute([$data['etudiant_id'], $data['cours_id']]);
$existingNote = $stmt->fetch();

if ($existingNote) {
    // --- RÈGLE MÉTIER : Note verrouillée ---
    // Si la note est verrouillée ET que l'utilisateur n'est pas admin → refus
    if ($existingNote['verrouille'] && $currentUser['role'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['error' => 'Cette note est verrouillée et ne peut plus être modifiée.']);
        exit;
    }

    // Mise à jour de la note existante
    $stmt = $pdo->prepare("UPDATE notes SET note = ?, commentaire = ?, date_saisie = NOW() WHERE id = ?");
    $stmt->execute([
        $data['note'],
        $data['commentaire'] ?? null,
        $existingNote['id'],
    ]);
    echo json_encode(['message' => 'Note mise à jour avec succès']);

} else {
    // Création d'une nouvelle note (INSERT)
    $stmt = $pdo->prepare(
        "INSERT INTO notes (etudiant_id, cours_id, note, commentaire) VALUES (?, ?, ?, ?)"
    );
    $stmt->execute([
        $data['etudiant_id'],
        $data['cours_id'],
        $data['note'],
        $data['commentaire'] ?? null,
    ]);
    http_response_code(201);
    echo json_encode(['message' => 'Note enregistrée avec succès']);
}
