<?php
// ============================================================
// api/grades/getByCourse.php — Liste des étudiants + notes d'un cours
// Méthode : GET | Param URL : ?cours_id=X
// Accès : enseignant ou admin
//
// Retourne TOUS les étudiants inscrits au cours,
// avec leur note si elle existe (NULL sinon).
// Cela permet à l'enseignant de saisir une note pour tout le monde.
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

// Seuls les enseignants et admins peuvent consulter les notes
requireRole(['enseignant', 'admin']);

// Récupération du paramètre cours_id depuis l'URL
$coursId = $_GET['cours_id'] ?? null;
if (!$coursId) {
    http_response_code(400);
    echo json_encode(['error' => 'Paramètre cours_id requis']);
    exit;
}

// Requête : on joint inscriptions → étudiants → users
// et on fait un LEFT JOIN avec notes pour inclure les étudiants sans note
$stmt = $pdo->prepare("
    SELECT
        e.id           AS etudiant_id,
        e.numero,
        u.nom,
        u.prenom,
        n.id           AS note_id,
        n.note,
        n.commentaire,
        n.verrouille,
        n.date_saisie
    FROM inscriptions i
    JOIN etudiants e ON e.id = i.etudiant_id
    JOIN users u ON u.id = e.user_id
    LEFT JOIN notes n ON n.etudiant_id = e.id AND n.cours_id = ?
    WHERE i.cours_id = ?
      AND i.statut = 'actif'
    ORDER BY u.nom, u.prenom
");
$stmt->execute([$coursId, $coursId]);

// On ajoute un champ id pour la compatibilité avec le composant frontend
$result = $stmt->fetchAll();
// Normalisation : si pas de note_id, on crée quand même un id unique pour la clé React
foreach ($result as &$row) {
    $row['id'] = $row['note_id'] ?? ('new_' . $row['etudiant_id']);
}

echo json_encode($result);
