<?php
// ============================================================
// api/teachers/create.php — Créer un enseignant
// Méthode : POST
// Accès : admin uniquement
// Body JSON : { nom, prenom, email, password, specialite, bureau }
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); echo json_encode(['error' => 'Méthode non autorisée']); exit;
}

$data = json_decode(file_get_contents('php://input'), true);

foreach (['nom','prenom','email','password'] as $field) {
    if (empty($data[$field])) {
        http_response_code(400);
        echo json_encode(['error' => "Champ '$field' obligatoire"]); exit;
    }
}

// Vérification email unique
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$data['email']]);
if ($stmt->fetch()) {
    http_response_code(409); echo json_encode(['error' => 'Email déjà utilisé']); exit;
}

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("INSERT INTO users (nom, prenom, email, password, role) VALUES (?,?,?,?,'enseignant')");
    $stmt->execute([$data['nom'], $data['prenom'], $data['email'], password_hash($data['password'], PASSWORD_DEFAULT)]);
    $userId = $pdo->lastInsertId();

    $stmt = $pdo->prepare("INSERT INTO enseignants (user_id, specialite, bureau) VALUES (?,?,?)");
    $stmt->execute([$userId, $data['specialite'] ?? null, $data['bureau'] ?? null]);

    $pdo->commit();
    http_response_code(201);
    echo json_encode(['message' => 'Enseignant créé avec succès']);
} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
