<?php
// ============================================================
// api/teachers/getAll.php — Liste tous les enseignants
// Méthode : GET
// Accès : admin uniquement
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireRole('admin');

$stmt = $pdo->query("
    SELECT
        en.id,
        en.specialite,
        en.bureau,
        u.nom,
        u.prenom,
        u.email,
        u.created_at,
        COUNT(c.id) as nb_cours   -- compte combien de cours chaque enseignant gère
    FROM enseignants en
    JOIN users u ON u.id = en.user_id
    LEFT JOIN cours c ON c.enseignant_id = en.id  -- LEFT JOIN = inclure même si 0 cours
    GROUP BY en.id, en.specialite, en.bureau, u.nom, u.prenom, u.email, u.created_at
    ORDER BY u.nom
");

echo json_encode($stmt->fetchAll());
