<?php
// ============================================================
// api/teachers/delete.php — Supprimer un enseignant
// Méthode : DELETE | URL param : ?id=X | Accès : admin
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    http_response_code(405); echo json_encode(['error' => 'Méthode non autorisée']); exit;
}

$id = $_GET['id'] ?? null;
if (!$id) { http_response_code(400); echo json_encode(['error' => 'ID manquant']); exit; }

$stmt = $pdo->prepare("SELECT user_id FROM enseignants WHERE id = ?");
$stmt->execute([$id]);
$ens = $stmt->fetch();

if (!$ens) { http_response_code(404); echo json_encode(['error' => 'Enseignant introuvable']); exit; }

// Supprimer le user → cascade sur enseignants
$pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$ens['user_id']]);

echo json_encode(['message' => 'Enseignant supprimé avec succès']);
