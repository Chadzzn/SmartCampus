<?php
// ============================================================
// api/teachers/update.php — Modifier un enseignant
// Méthode : PUT | URL param : ?id=X
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405); echo json_encode(['error' => 'Méthode non autorisée']); exit;
}

$id   = $_GET['id'] ?? null;
$data = json_decode(file_get_contents('php://input'), true);

$stmt = $pdo->prepare("SELECT user_id FROM enseignants WHERE id = ?");
$stmt->execute([$id]);
$ens = $stmt->fetch();

if (!$ens) {
    http_response_code(404); echo json_encode(['error' => 'Enseignant introuvable']); exit;
}

try {
    $pdo->beginTransaction();

    $pdo->prepare("UPDATE users SET nom=?, prenom=?, email=? WHERE id=?")
        ->execute([$data['nom'], $data['prenom'], $data['email'], $ens['user_id']]);

    $pdo->prepare("UPDATE enseignants SET specialite=?, bureau=? WHERE id=?")
        ->execute([$data['specialite'] ?? null, $data['bureau'] ?? null, $id]);

    $pdo->commit();
    echo json_encode(['message' => 'Enseignant mis à jour']);
} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
