<?php
// ============================================================
// api/auth/logout.php — Déconnexion d'un utilisateur
// Méthode : POST
// Détruit la session PHP côté serveur
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Méthode non autorisée']);
    exit;
}

// --- Destruction complète de la session ---
// 1. On vide le tableau de session
$_SESSION = [];

// 2. On supprime le cookie de session dans le navigateur
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(), '',
        time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 3. On détruit la session côté serveur
session_destroy();

http_response_code(200);
echo json_encode(['message' => 'Déconnexion réussie']);
