<?php
// ============================================================
// api/auth/me.php — Vérifie si l'utilisateur est connecté
// Méthode : GET
// Utilisé par React au démarrage pour savoir si une session
// est déjà active (ex: après un refresh de la page)
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';

// Si non connecté, requireAuth() renverra une 401 automatiquement
requireAuth();

// On retourne les données de l'utilisateur connecté
$user = getCurrentUser();
http_response_code(200);
echo json_encode(['user' => $user]);
