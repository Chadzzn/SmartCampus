<?php
// ============================================================
// api/auth/login.php — Connexion d'un utilisateur
// Méthode : POST
// Body JSON : { "email": "...", "password": "..." }
// Réponse : les infos de l'utilisateur si succès, erreur sinon
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

// Ce endpoint n'accepte que les requêtes POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Méthode non autorisée']);
    exit;
}

// --- Lecture du corps de la requête ---
// Le frontend envoie les données en JSON, on les décode ici
$data = json_decode(file_get_contents('php://input'), true);

// Vérification que les champs obligatoires sont présents
if (empty($data['email']) || empty($data['password'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Email et mot de passe requis']);
    exit;
}

// --- Recherche de l'utilisateur dans la base de données ---
// On utilise une requête préparée pour éviter les injections SQL
// (jamais d'interpolation directe : $pdo->query("... WHERE email = '$email'") est DANGEREUX)
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$data['email']]);
$user = $stmt->fetch();

// --- Vérification du mot de passe ---
// password_verify() compare le mot de passe saisi avec le hash stocké en BDD
// C'est beaucoup plus sécurisé que de stocker les mots de passe en clair
if (!$user || !password_verify($data['password'], $user['password'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Email ou mot de passe incorrect']);
    exit;
}

// --- Création de la session PHP ---
// On stocke les informations importantes dans $_SESSION
// Ces données seront disponibles dans tous les autres fichiers PHP
// tant que la session est active (le cookie de session est envoyé au navigateur)
$_SESSION['user_id']     = $user['id'];
$_SESSION['user_role']   = $user['role'];
$_SESSION['user_nom']    = $user['nom'];
$_SESSION['user_prenom'] = $user['prenom'];
$_SESSION['user_email']  = $user['email'];

// --- Réponse au frontend ---
// On ne renvoie JAMAIS le mot de passe hashé dans la réponse
http_response_code(200);
echo json_encode([
    'message' => 'Connexion réussie',
    'user' => [
        'id'     => $user['id'],
        'nom'    => $user['nom'],
        'prenom' => $user['prenom'],
        'email'  => $user['email'],
        'role'   => $user['role'],
    ]
]);
