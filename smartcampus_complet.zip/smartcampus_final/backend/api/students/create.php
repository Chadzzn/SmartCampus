<?php
// ============================================================
// api/students/create.php — Créer un nouvel étudiant
// Méthode : POST
// Accès : admin uniquement
// Body JSON : { nom, prenom, email, password, numero, promotion, groupe }
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Méthode non autorisée']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

// --- Validation des champs obligatoires ---
$required = ['nom', 'prenom', 'email', 'password', 'numero', 'promotion'];
foreach ($required as $field) {
    if (empty($data[$field])) {
        http_response_code(400);
        echo json_encode(['error' => "Le champ '$field' est obligatoire"]);
        exit;
    }
}

// --- Vérification que l'email n'est pas déjà utilisé ---
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$data['email']]);
if ($stmt->fetch()) {
    http_response_code(409); // 409 Conflict
    echo json_encode(['error' => 'Cet email est déjà utilisé']);
    exit;
}

// --- Vérification que le numéro étudiant n'existe pas déjà ---
$stmt = $pdo->prepare("SELECT id FROM etudiants WHERE numero = ?");
$stmt->execute([$data['numero']]);
if ($stmt->fetch()) {
    http_response_code(409);
    echo json_encode(['error' => 'Ce numéro étudiant est déjà utilisé']);
    exit;
}

// --- Insertion dans les deux tables (transaction) ---
// Une transaction garantit que les deux insertions réussissent ensemble.
// Si l'une échoue, l'autre est annulée (rollback).
try {
    $pdo->beginTransaction();

    // 1. Créer le compte utilisateur avec mot de passe hashé
    $stmt = $pdo->prepare("
        INSERT INTO users (nom, prenom, email, password, role)
        VALUES (?, ?, ?, ?, 'etudiant')
    ");
    $stmt->execute([
        $data['nom'],
        $data['prenom'],
        $data['email'],
        password_hash($data['password'], PASSWORD_DEFAULT) // hashage sécurisé
    ]);

    $userId = $pdo->lastInsertId(); // récupère l'id auto-incrémenté

    // 2. Créer le profil étudiant associé
    $stmt = $pdo->prepare("
        INSERT INTO etudiants (user_id, numero, promotion, groupe)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([
        $userId,
        $data['numero'],
        $data['promotion'],
        $data['groupe'] ?? null
    ]);

    $pdo->commit(); // valide la transaction

    http_response_code(201); // 201 Created
    echo json_encode(['message' => 'Étudiant créé avec succès', 'user_id' => $userId]);

} catch (Exception $e) {
    $pdo->rollBack(); // annule tout si erreur
    http_response_code(500);
    echo json_encode(['error' => 'Erreur lors de la création : ' . $e->getMessage()]);
}
