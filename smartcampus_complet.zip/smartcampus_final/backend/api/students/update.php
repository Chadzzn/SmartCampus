<?php
// ============================================================
// api/students/update.php — Modifier un étudiant
// Méthode : PUT
// Accès : admin uniquement
// URL param : ?id=X
// Body JSON : { nom, prenom, email, promotion, groupe }
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405);
    echo json_encode(['error' => 'Méthode non autorisée']);
    exit;
}

// Récupération de l'id depuis l'URL (?id=X)
$id = $_GET['id'] ?? null;
if (!$id) {
    http_response_code(400);
    echo json_encode(['error' => 'ID manquant']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

// --- Vérification que l'étudiant existe ---
$stmt = $pdo->prepare("SELECT e.id, e.user_id FROM etudiants e WHERE e.id = ?");
$stmt->execute([$id]);
$etudiant = $stmt->fetch();

if (!$etudiant) {
    http_response_code(404);
    echo json_encode(['error' => 'Étudiant introuvable']);
    exit;
}

// --- Mise à jour dans les deux tables ---
try {
    $pdo->beginTransaction();

    // Mise à jour de la table users
    $stmt = $pdo->prepare("
        UPDATE users SET nom = ?, prenom = ?, email = ?
        WHERE id = ?
    ");
    $stmt->execute([
        $data['nom'],
        $data['prenom'],
        $data['email'],
        $etudiant['user_id']
    ]);

    // Mise à jour de la table etudiants
    $stmt = $pdo->prepare("
        UPDATE etudiants SET promotion = ?, groupe = ?
        WHERE id = ?
    ");
    $stmt->execute([
        $data['promotion'] ?? null,
        $data['groupe'] ?? null,
        $id
    ]);

    $pdo->commit();

    http_response_code(200);
    echo json_encode(['message' => 'Étudiant mis à jour avec succès']);

} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Erreur : ' . $e->getMessage()]);
}
