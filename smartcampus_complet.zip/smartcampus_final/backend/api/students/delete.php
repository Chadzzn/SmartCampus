<?php
// ============================================================
// api/students/delete.php — Supprimer un étudiant
// Méthode : DELETE
// Accès : admin uniquement
// URL param : ?id=X
// Note : la suppression de users cascade automatiquement
//        sur etudiants, inscriptions, notes (ON DELETE CASCADE)
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    http_response_code(405);
    echo json_encode(['error' => 'Méthode non autorisée']);
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) {
    http_response_code(400);
    echo json_encode(['error' => 'ID manquant']);
    exit;
}

// Récupère l'user_id associé à cet étudiant
$stmt = $pdo->prepare("SELECT user_id FROM etudiants WHERE id = ?");
$stmt->execute([$id]);
$etudiant = $stmt->fetch();

if (!$etudiant) {
    http_response_code(404);
    echo json_encode(['error' => 'Étudiant introuvable']);
    exit;
}

// On supprime le user → grâce à ON DELETE CASCADE dans le SQL,
// l'entrée dans "etudiants", "inscriptions" et "notes" sera supprimée aussi
$stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
$stmt->execute([$etudiant['user_id']]);

http_response_code(200);
echo json_encode(['message' => 'Étudiant supprimé avec succès']);
