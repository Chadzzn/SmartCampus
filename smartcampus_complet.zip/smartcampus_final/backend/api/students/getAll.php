<?php
// ============================================================
// api/students/getAll.php — Liste tous les étudiants
// Méthode : GET
// Accès : admin uniquement
// Retourne : tableau de tous les étudiants avec leurs infos user
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

// Seul l'admin peut voir tous les étudiants
requireRole('admin');

// --- Requête SQL avec JOIN ---
// On joint la table users et etudiants pour récupérer toutes les infos
// en une seule requête (plus efficace que deux requêtes séparées)
$stmt = $pdo->query("
    SELECT
        e.id,
        e.numero,
        e.promotion,
        e.groupe,
        u.nom,
        u.prenom,
        u.email,
        u.created_at
    FROM etudiants e
    JOIN users u ON u.id = e.user_id
    ORDER BY u.nom, u.prenom
");

$etudiants = $stmt->fetchAll();

http_response_code(200);
echo json_encode($etudiants);
