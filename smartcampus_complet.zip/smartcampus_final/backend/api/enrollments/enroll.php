<?php
// ============================================================
// api/enrollments/enroll.php — Inscrire un étudiant à un cours
// Méthode : POST | Accès : admin ou l'étudiant lui-même
// Body JSON : { etudiant_id, cours_id }
//
// RÈGLES MÉTIER IMPLÉMENTÉES :
//   1. Un étudiant ne peut pas s'inscrire 2 fois au même cours
//   2. La capacité maximale d'un cours ne peut pas être dépassée
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); echo json_encode(['error' => 'Méthode non autorisée']); exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (empty($data['etudiant_id']) || empty($data['cours_id'])) {
    http_response_code(400); echo json_encode(['error' => 'etudiant_id et cours_id requis']); exit;
}

// --- RÈGLE MÉTIER 1 : Vérification de la double inscription ---
$stmt = $pdo->prepare("SELECT id FROM inscriptions WHERE etudiant_id = ? AND cours_id = ?");
$stmt->execute([$data['etudiant_id'], $data['cours_id']]);
if ($stmt->fetch()) {
    http_response_code(409);
    echo json_encode(['error' => 'Cet étudiant est déjà inscrit à ce cours']);
    exit;
}

// --- RÈGLE MÉTIER 2 : Vérification de la capacité maximale ---
$stmt = $pdo->prepare("
    SELECT c.capacite_max, COUNT(i.id) as nb_inscrits
    FROM cours c
    LEFT JOIN inscriptions i ON i.cours_id = c.id AND i.statut = 'actif'
    WHERE c.id = ?
    GROUP BY c.id, c.capacite_max
");
$stmt->execute([$data['cours_id']]);
$cours = $stmt->fetch();

if (!$cours) {
    http_response_code(404); echo json_encode(['error' => 'Cours introuvable']); exit;
}

if ($cours['nb_inscrits'] >= $cours['capacite_max']) {
    http_response_code(409);
    echo json_encode(['error' => 'Ce cours est complet (capacité maximale atteinte)']);
    exit;
}

// --- Tout est OK : on inscrit l'étudiant ---
$stmt = $pdo->prepare("INSERT INTO inscriptions (etudiant_id, cours_id) VALUES (?, ?)");
$stmt->execute([$data['etudiant_id'], $data['cours_id']]);

http_response_code(201);
echo json_encode(['message' => 'Inscription réussie']);
