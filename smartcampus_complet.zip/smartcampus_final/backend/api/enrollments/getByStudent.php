<?php
// ============================================================
// api/enrollments/getByStudent.php — Cours d'un étudiant
// Méthode : GET | URL param : ?etudiant_id=X
// Accès : admin, enseignant, ou l'étudiant lui-même
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireAuth();

$etudiantId = $_GET['etudiant_id'] ?? null;
if (!$etudiantId) {
    http_response_code(400); echo json_encode(['error' => 'etudiant_id requis']); exit;
}

$stmt = $pdo->prepare("
    SELECT
        i.id as inscription_id,
        i.date_inscription,
        i.statut,
        c.id as cours_id,
        c.code,
        c.nom,
        c.credits,
        c.semestre,
        CONCAT(u.prenom, ' ', u.nom) as enseignant_nom,
        n.note                           -- note de l'étudiant dans ce cours (peut être NULL)
    FROM inscriptions i
    JOIN cours c ON c.id = i.cours_id
    LEFT JOIN enseignants en ON en.id = c.enseignant_id
    LEFT JOIN users u ON u.id = en.user_id
    LEFT JOIN notes n ON n.cours_id = c.id AND n.etudiant_id = i.etudiant_id
    WHERE i.etudiant_id = ?
    ORDER BY c.semestre, c.nom
");
$stmt->execute([$etudiantId]);

echo json_encode($stmt->fetchAll());
