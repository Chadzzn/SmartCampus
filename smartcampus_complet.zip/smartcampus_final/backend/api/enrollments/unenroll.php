<?php
// ============================================================
// api/enrollments/unenroll.php — Désinscrire un étudiant d'un cours
// Méthode : DELETE | Params : ?etudiant_id=X&cours_id=Y
// Accès : admin ou l'étudiant lui-même
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    http_response_code(405); echo json_encode(['error' => 'Méthode non autorisée']); exit;
}

$etudiantId = $_GET['etudiant_id'] ?? null;
$coursId    = $_GET['cours_id']    ?? null;

if (!$etudiantId || !$coursId) {
    http_response_code(400); echo json_encode(['error' => 'etudiant_id et cours_id requis']); exit;
}

$stmt = $pdo->prepare("DELETE FROM inscriptions WHERE etudiant_id = ? AND cours_id = ?");
$stmt->execute([$etudiantId, $coursId]);

if ($stmt->rowCount() === 0) {
    http_response_code(404); echo json_encode(['error' => 'Inscription introuvable']); exit;
}

echo json_encode(['message' => 'Désinscription effectuée avec succès']);
