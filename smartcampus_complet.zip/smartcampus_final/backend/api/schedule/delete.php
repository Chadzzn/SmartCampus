<?php
// ============================================================
// api/schedule/delete.php — Supprimer une séance
// Méthode : DELETE | URL param : ?id=X | Accès : admin
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    http_response_code(405); echo json_encode(['error' => 'Méthode non autorisée']); exit;
}

$id = $_GET['id'] ?? null;
if (!$id) { http_response_code(400); echo json_encode(['error' => 'ID manquant']); exit; }

$stmt = $pdo->prepare("DELETE FROM seances WHERE id = ?");
$stmt->execute([$id]);

if ($stmt->rowCount() === 0) {
    http_response_code(404); echo json_encode(['error' => 'Séance introuvable']); exit;
}

echo json_encode(['message' => 'Séance supprimée']);
