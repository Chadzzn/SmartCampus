<?php
// ============================================================
// api/schedule/getAll.php — Emploi du temps
// Méthode : GET
// Accès : tous les utilisateurs connectés
// Params optionnels : ?cours_id=X ou ?etudiant_id=X ou ?enseignant_id=X
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireAuth();

// Construire la requête selon les filtres demandés
$sql = "
    SELECT
        s.id,
        s.date_seance,
        s.heure_debut,
        s.heure_fin,
        s.salle,
        s.type_seance,
        c.id as cours_id,
        c.code,
        c.nom as cours_nom,
        c.promotion,
        CONCAT(u.prenom, ' ', u.nom) as enseignant_nom
    FROM seances s
    JOIN cours c ON c.id = s.cours_id
    LEFT JOIN enseignants en ON en.id = c.enseignant_id
    LEFT JOIN users u ON u.id = en.user_id
";

$params = [];
$conditions = [];

// Filtre par étudiant : ne montre que les cours auxquels il est inscrit
if (!empty($_GET['etudiant_id'])) {
    $sql .= " JOIN inscriptions i ON i.cours_id = c.id AND i.etudiant_id = ? AND i.statut = 'actif'";
    $params[] = $_GET['etudiant_id'];
}

// Filtre par enseignant
if (!empty($_GET['enseignant_id'])) {
    $conditions[] = "c.enseignant_id = ?";
    $params[] = $_GET['enseignant_id'];
}

// Filtre par cours
if (!empty($_GET['cours_id'])) {
    $conditions[] = "s.cours_id = ?";
    $params[] = $_GET['cours_id'];
}

if (!empty($conditions)) {
    $sql .= " WHERE " . implode(' AND ', $conditions);
}

$sql .= " ORDER BY s.date_seance, s.heure_debut";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

echo json_encode($stmt->fetchAll());
