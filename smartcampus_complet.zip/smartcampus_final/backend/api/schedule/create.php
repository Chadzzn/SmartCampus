<?php
// ============================================================
// api/schedule/create.php — Ajouter une séance à l'emploi du temps
// Méthode : POST | Accès : admin uniquement
// Body JSON : { cours_id, date_seance, heure_debut, heure_fin, salle, type_seance }
// ============================================================

require_once __DIR__ . '/../../middleware/auth.php';
require_once __DIR__ . '/../../config/db.php';

requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); echo json_encode(['error' => 'Méthode non autorisée']); exit;
}

$data = json_decode(file_get_contents('php://input'), true);

foreach (['cours_id','date_seance','heure_debut','heure_fin'] as $f) {
    if (empty($data[$f])) {
        http_response_code(400); echo json_encode(['error' => "Champ '$f' obligatoire"]); exit;
    }
}

$stmt = $pdo->prepare("
    INSERT INTO seances (cours_id, date_seance, heure_debut, heure_fin, salle, type_seance)
    VALUES (?, ?, ?, ?, ?, ?)
");
$stmt->execute([
    $data['cours_id'],
    $data['date_seance'],
    $data['heure_debut'],
    $data['heure_fin'],
    $data['salle']       ?? null,
    $data['type_seance'] ?? 'CM',
]);

http_response_code(201);
echo json_encode(['message' => 'Séance ajoutée', 'id' => $pdo->lastInsertId()]);
