# 🎓 SmartCampus — Plateforme de gestion académique

Projet Web Dynamique : React (frontend) + PHP (backend) + MySQL (base de données).

---

## 📁 Structure du projet

```
smartcampus/
├── frontend/          ← Application React (Vite)
├── backend/           ← API REST en PHP
└── database/          ← Script SQL
```

---

## 🚀 Installation pas à pas

### 1. Base de données

1. Ouvre **phpMyAdmin** (via XAMPP : http://localhost/phpmyadmin)
2. Clique sur **"Importer"**
3. Sélectionne le fichier `database/smartcampus.sql`
4. Clique **"Exécuter"**

La base de données `smartcampus` est créée avec toutes les tables et des données de test.

---

### 2. Backend PHP

1. Copie le dossier `backend/` dans `C:/xampp/htdocs/smartcampus/` (ou `/var/www/html/` sur Linux)
2. Modifie `backend/config/db.php` si ton mot de passe MySQL n'est pas vide
3. Démarre Apache dans le panneau XAMPP
4. L'API sera accessible sur : `http://localhost/smartcampus/backend/api/`

---

### 3. Frontend React

```bash
# Aller dans le dossier frontend
cd frontend

# Installer les dépendances
npm install

# Lancer le serveur de développement
npm run dev
```

L'application sera disponible sur : **http://localhost:5173**

---

## 👥 Comptes de test

| Rôle        | Email                        | Mot de passe |
|-------------|------------------------------|--------------|
| Admin       | admin@smartcampus.fr         | password     |
| Enseignant  | mdupont@smartcampus.fr       | password     |
| Enseignant  | pmartin@smartcampus.fr       | password     |
| Étudiant    | lbernard@smartcampus.fr      | password     |
| Étudiant    | epetit@smartcampus.fr        | password     |

> ⚠️ Le hash dans la BDD correspond à `password` (généré avec `password_hash`).

---

## 🔌 Endpoints API

### Authentification
| Méthode | URL | Description |
|---------|-----|-------------|
| POST | `/api/auth/login.php` | Connexion |
| POST | `/api/auth/logout.php` | Déconnexion |
| GET  | `/api/auth/me.php` | Utilisateur connecté |

### Étudiants (admin)
| Méthode | URL | Description |
|---------|-----|-------------|
| GET    | `/api/students/getAll.php` | Liste des étudiants |
| POST   | `/api/students/create.php` | Créer un étudiant |
| PUT    | `/api/students/update.php?id=X` | Modifier |
| DELETE | `/api/students/delete.php?id=X` | Supprimer |

### Enseignants (admin)
| Méthode | URL | Description |
|---------|-----|-------------|
| GET    | `/api/teachers/getAll.php` | Liste |
| POST   | `/api/teachers/create.php` | Créer |
| PUT    | `/api/teachers/update.php?id=X` | Modifier |
| DELETE | `/api/teachers/delete.php?id=X` | Supprimer |

### Cours
| Méthode | URL | Description |
|---------|-----|-------------|
| GET    | `/api/courses/getAll.php` | Liste tous les cours |
| POST   | `/api/courses/create.php` | Créer (admin) |
| PUT    | `/api/courses/update.php?id=X` | Modifier (admin) |
| DELETE | `/api/courses/delete.php?id=X` | Supprimer (admin) |

### Inscriptions
| Méthode | URL | Description |
|---------|-----|-------------|
| POST   | `/api/enrollments/enroll.php` | Inscrire |
| DELETE | `/api/enrollments/unenroll.php?etudiant_id=X&cours_id=Y` | Désinscrire |
| GET    | `/api/enrollments/getByStudent.php?etudiant_id=X` | Cours d'un étudiant |

### Notes
| Méthode | URL | Description |
|---------|-----|-------------|
| GET  | `/api/grades/getByCourse.php?cours_id=X` | Notes d'un cours |
| POST | `/api/grades/setByCourse.php` | Saisir une note |
| POST | `/api/grades/lock.php` | Verrouiller les notes |

### Emploi du temps
| Méthode | URL | Description |
|---------|-----|-------------|
| GET    | `/api/schedule/getAll.php` | Toutes les séances |
| POST   | `/api/schedule/create.php` | Ajouter une séance (admin) |
| DELETE | `/api/schedule/delete.php?id=X` | Supprimer (admin) |

---

## 🛠️ Technologies utilisées

- **Frontend** : React 18, React Router v6, Axios, Vite
- **Backend** : PHP 8, PDO (MySQL), Sessions PHP
- **Base de données** : MySQL / MariaDB
- **Serveur local** : XAMPP (Apache + MySQL)
