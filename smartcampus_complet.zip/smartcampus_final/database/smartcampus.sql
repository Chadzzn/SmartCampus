-- ============================================================
-- SmartCampus — Script SQL complet
-- Crée toutes les tables et insère des données de test
-- ============================================================

-- On crée la base de données si elle n'existe pas encore
CREATE DATABASE IF NOT EXISTS smartcampus CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smartcampus;

-- ============================================================
-- TABLE : users
-- Contient tous les utilisateurs (étudiants, enseignants, admins)
-- Le champ "role" détermine les permissions de chaque utilisateur
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    nom         VARCHAR(100) NOT NULL,
    prenom      VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,          -- mot de passe hashé avec password_hash()
    role        ENUM('etudiant','enseignant','admin') NOT NULL DEFAULT 'etudiant',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLE : etudiants
-- Informations académiques spécifiques aux étudiants
-- Reliée à la table users (un étudiant EST un user)
-- ============================================================
CREATE TABLE IF NOT EXISTS etudiants (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL UNIQUE,            -- lien avec la table users
    numero      VARCHAR(20) NOT NULL UNIQUE,    -- numéro étudiant (ex: ETU2024001)
    promotion   VARCHAR(50),                    -- ex: ING2, BUT1...
    groupe      VARCHAR(20),                    -- ex: A, B, TP1...
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLE : enseignants
-- Informations spécifiques aux enseignants
-- ============================================================
CREATE TABLE IF NOT EXISTS enseignants (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL UNIQUE,
    specialite  VARCHAR(100),                   -- ex: Mathématiques, Informatique...
    bureau      VARCHAR(50),                    -- numéro de bureau
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLE : cours
-- Représente un cours/matière de la plateforme
-- ============================================================
CREATE TABLE IF NOT EXISTS cours (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    code            VARCHAR(20) NOT NULL UNIQUE, -- ex: WEB201, MATH301
    nom             VARCHAR(150) NOT NULL,
    description     TEXT,
    credits         INT DEFAULT 3,               -- nombre de crédits ECTS
    capacite_max    INT DEFAULT 30,              -- nombre max d'étudiants
    semestre        VARCHAR(20),                 -- ex: S3, S4
    promotion       VARCHAR(50),                 -- promo cible
    enseignant_id   INT,                         -- enseignant responsable
    FOREIGN KEY (enseignant_id) REFERENCES enseignants(id) ON DELETE SET NULL
);

-- ============================================================
-- TABLE : inscriptions
-- Liaison entre étudiants et cours (many-to-many)
-- Règle métier : un étudiant ne peut pas s'inscrire 2 fois au même cours
-- ============================================================
CREATE TABLE IF NOT EXISTS inscriptions (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    etudiant_id     INT NOT NULL,
    cours_id        INT NOT NULL,
    date_inscription TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    statut          ENUM('actif','abandonne') DEFAULT 'actif',
    UNIQUE KEY unique_inscription (etudiant_id, cours_id),  -- empêche la double inscription
    FOREIGN KEY (etudiant_id) REFERENCES etudiants(id) ON DELETE CASCADE,
    FOREIGN KEY (cours_id)    REFERENCES cours(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLE : notes
-- Notes des étudiants pour chaque cours
-- Règle métier : une note peut être verrouillée après validation finale
-- ============================================================
CREATE TABLE IF NOT EXISTS notes (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    etudiant_id INT NOT NULL,
    cours_id    INT NOT NULL,
    note        DECIMAL(4,2),                   -- note sur 20 (ex: 14.50)
    commentaire TEXT,
    verrouille  BOOLEAN DEFAULT FALSE,          -- TRUE = note définitive, non modifiable
    date_saisie TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_note (etudiant_id, cours_id),
    FOREIGN KEY (etudiant_id) REFERENCES etudiants(id) ON DELETE CASCADE,
    FOREIGN KEY (cours_id)    REFERENCES cours(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLE : seances
-- Représente une séance de cours dans l'emploi du temps
-- ============================================================
CREATE TABLE IF NOT EXISTS seances (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    cours_id    INT NOT NULL,
    date_seance DATE NOT NULL,
    heure_debut TIME NOT NULL,
    heure_fin   TIME NOT NULL,
    salle       VARCHAR(50),
    type_seance ENUM('CM','TD','TP') DEFAULT 'CM',  -- Cours Magistral, TD, TP
    FOREIGN KEY (cours_id) REFERENCES cours(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLE : presences
-- Enregistre la présence/absence d'un étudiant à une séance
-- ============================================================
CREATE TABLE IF NOT EXISTS presences (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    etudiant_id INT NOT NULL,
    seance_id   INT NOT NULL,
    present     BOOLEAN DEFAULT FALSE,
    UNIQUE KEY unique_presence (etudiant_id, seance_id),
    FOREIGN KEY (etudiant_id) REFERENCES etudiants(id) ON DELETE CASCADE,
    FOREIGN KEY (seance_id)   REFERENCES seances(id) ON DELETE CASCADE
);

-- ============================================================
-- DONNÉES DE TEST
-- Permet de tester l'application immédiatement sans tout saisir
-- Mot de passe pour tous : "password123"
-- ============================================================

-- Insertion des comptes utilisateurs
-- Note : password_hash("password123", PASSWORD_DEFAULT) est pré-calculé ici
INSERT INTO users (nom, prenom, email, password, role) VALUES
('Admin',     'Super',    'admin@smartcampus.fr',    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('Dupont',    'Marie',    'mdupont@smartcampus.fr',  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'enseignant'),
('Martin',    'Pierre',   'pmartin@smartcampus.fr',  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'enseignant'),
('Bernard',   'Lucas',    'lbernard@smartcampus.fr', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'etudiant'),
('Petit',     'Emma',     'epetit@smartcampus.fr',   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'etudiant'),
('Moreau',    'Hugo',     'hmoreau@smartcampus.fr',  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'etudiant'),
('Simon',     'Léa',      'lsimon@smartcampus.fr',   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'etudiant');

-- Insertion des profils enseignants
INSERT INTO enseignants (user_id, specialite, bureau) VALUES
(2, 'Développement Web', 'B204'),
(3, 'Mathématiques', 'C102');

-- Insertion des profils étudiants
INSERT INTO etudiants (user_id, numero, promotion, groupe) VALUES
(4, 'ETU2024001', 'ING2', 'A'),
(5, 'ETU2024002', 'ING2', 'A'),
(6, 'ETU2024003', 'ING2', 'B'),
(7, 'ETU2024004', 'ING2', 'B');

-- Insertion des cours
INSERT INTO cours (code, nom, description, credits, capacite_max, semestre, promotion, enseignant_id) VALUES
('WEB201', 'Web Dynamique',       'PHP, MySQL, React et architecture client-serveur', 6, 30, 'S4', 'ING2', 1),
('MATH301','Analyse et Algèbre',  'Intégration, algèbre linéaire et probabilités',    6, 35, 'S4', 'ING2', 2),
('INFO202','Algorithmique',       'Structures de données et algorithmique avancée',   4, 30, 'S4', 'ING2', 1),
('PHY201', 'Physique Appliquée',  'Mécanique et thermodynamique',                     4, 35, 'S4', 'ING2', 2);

-- Inscriptions aux cours
INSERT INTO inscriptions (etudiant_id, cours_id) VALUES
(1, 1), (1, 2), (1, 3),
(2, 1), (2, 2), (2, 4),
(3, 1), (3, 3), (3, 4),
(4, 2), (4, 3), (4, 4);

-- Notes (quelques notes pour illustration)
INSERT INTO notes (etudiant_id, cours_id, note, commentaire) VALUES
(1, 1, 15.50, 'Bon travail'),
(1, 2, 12.00, 'Peut mieux faire'),
(2, 1, 17.00, 'Excellent'),
(2, 2, 14.50, 'Bien'),
(3, 1, 11.00, 'Assez bien'),
(4, 2, 16.00, 'Très bien');

-- Séances dans l'emploi du temps
INSERT INTO seances (cours_id, date_seance, heure_debut, heure_fin, salle, type_seance) VALUES
(1, '2026-05-27', '08:00:00', '10:00:00', 'Amphi A', 'CM'),
(1, '2026-05-27', '10:00:00', '12:00:00', 'Info 1',  'TP'),
(2, '2026-05-27', '14:00:00', '16:00:00', 'Salle 12','CM'),
(3, '2026-05-28', '08:00:00', '10:00:00', 'Info 2',  'TP'),
(4, '2026-05-28', '14:00:00', '16:00:00', 'Labo 1',  'TD');
