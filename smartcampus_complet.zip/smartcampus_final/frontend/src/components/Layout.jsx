// ============================================================
// src/components/Layout.jsx — Mise en page commune
// Ce composant encapsule toutes les pages après connexion.
// Il affiche la Sidebar à gauche et le contenu de la page à droite.
// Utilisation : <Layout><MonComposantPage /></Layout>
// ============================================================

import Sidebar from './Sidebar';

function Layout({ children, title }) {
    return (
        <div style={styles.container}>
            {/* Barre latérale de navigation */}
            <Sidebar />

            {/* Zone de contenu principal */}
            <main style={styles.main}>
                {/* En-tête de la page avec le titre */}
                {title && (
                    <div style={styles.pageHeader}>
                        <h1 style={styles.pageTitle}>{title}</h1>
                    </div>
                )}

                {/* Contenu de la page (passé en tant qu'enfant) */}
                <div style={styles.content}>
                    {children}
                </div>
            </main>
        </div>
    );
}

const styles = {
    container:  { display:'flex', minHeight:'100vh', backgroundColor:'#f1f5f9' },
    main:       { flex:1, overflow:'auto' },
    pageHeader: { backgroundColor:'white', padding:'20px 32px', borderBottom:'1px solid #e2e8f0' },
    pageTitle:  { margin:0, fontSize:'22px', fontWeight:'700', color:'#1e293b' },
    content:    { padding:'32px' },
};

export default Layout;
