// ============================================================
// src/components/ProtectedRoute.jsx — Route protégée
// Ce composant protège les pages qui nécessitent une connexion.
// Il vérifie aussi que l'utilisateur a le bon rôle.
// Si non connecté → redirige vers /login
// Si mauvais rôle → redirige vers le dashboard approprié
// ============================================================

import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// props :
//   children  → le composant page à afficher si autorisé
//   roles     → tableau de rôles autorisés (ex: ['admin', 'enseignant'])
function ProtectedRoute({ children, roles }) {
    const { user } = useAuth(); // on récupère l'utilisateur depuis le contexte

    // Si l'utilisateur n'est pas connecté → redirection vers la page de login
    if (!user) {
        return <Navigate to="/login" replace />;
    }

    // Si des rôles sont spécifiés ET que l'utilisateur n'a pas le bon rôle
    if (roles && !roles.includes(user.role)) {
        // On redirige vers le dashboard approprié selon le rôle
        const dashboardPath = {
            admin:      '/admin',
            enseignant: '/enseignant',
            etudiant:   '/etudiant',
        }[user.role] || '/login';

        return <Navigate to={dashboardPath} replace />;
    }

    // Tout est OK → on affiche le composant enfant
    return children;
}

export default ProtectedRoute;
