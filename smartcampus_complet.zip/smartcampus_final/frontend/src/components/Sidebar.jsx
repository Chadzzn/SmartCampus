// ============================================================
// src/components/Sidebar.jsx — Barre de navigation latérale
// S'adapte automatiquement selon le rôle de l'utilisateur.
// Chaque rôle voit un menu différent.
// ============================================================

import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// Définition des menus par rôle
// Chaque entrée a : path (URL), label (texte), icon (emoji)
const MENUS = {
    admin: [
        { path: '/admin',              label: 'Tableau de bord', icon: '🏠' },
        { path: '/admin/etudiants',    label: 'Étudiants',       icon: '🎓' },
        { path: '/admin/enseignants',  label: 'Enseignants',     icon: '👨‍🏫' },
        { path: '/admin/cours',        label: 'Cours',           icon: '📚' },
        { path: '/admin/emploi-temps', label: 'Emploi du temps', icon: '📅' },
    ],
    enseignant: [
        { path: '/enseignant',            label: 'Tableau de bord', icon: '🏠' },
        { path: '/enseignant/mes-cours',  label: 'Mes cours',       icon: '📚' },
        { path: '/enseignant/notes',      label: 'Notes',           icon: '📝' },
        { path: '/enseignant/emploi-temps', label: 'Emploi du temps', icon: '📅' },
    ],
    etudiant: [
        { path: '/etudiant',              label: 'Tableau de bord', icon: '🏠' },
        { path: '/etudiant/mes-cours',    label: 'Mes cours',       icon: '📚' },
        { path: '/etudiant/mes-notes',    label: 'Mes notes',       icon: '📊' },
        { path: '/etudiant/emploi-temps', label: 'Emploi du temps', icon: '📅' },
    ],
};

function Sidebar() {
    const { user, logout } = useAuth();
    const navigate         = useNavigate();

    // Récupère le menu correspondant au rôle de l'utilisateur
    const menuItems = MENUS[user?.role] || [];

    const handleLogout = async () => {
        await logout();
        navigate('/login'); // redirige vers la page de connexion après déconnexion
    };

    return (
        <aside style={styles.sidebar}>
            {/* Logo / titre de l'application */}
            <div style={styles.logo}>
                <span style={styles.logoIcon}>🎓</span>
                <span style={styles.logoText}>SmartCampus</span>
            </div>

            {/* Informations de l'utilisateur connecté */}
            <div style={styles.userInfo}>
                <div style={styles.avatar}>{user?.prenom?.[0]}{user?.nom?.[0]}</div>
                <div>
                    <div style={styles.userName}>{user?.prenom} {user?.nom}</div>
                    {/* Affiche le rôle avec un badge coloré */}
                    <span style={{...styles.roleBadge, ...styles.roleColors[user?.role]}}>
                        {user?.role}
                    </span>
                </div>
            </div>

            {/* Liens de navigation */}
            <nav style={styles.nav}>
                {menuItems.map(item => (
                    <NavLink
                        key={item.path}
                        to={item.path}
                        end={item.path.split('/').length === 2} // exact match pour la racine
                        style={({ isActive }) => ({
                            ...styles.navLink,
                            ...(isActive ? styles.navLinkActive : {})
                        })}
                    >
                        <span style={styles.navIcon}>{item.icon}</span>
                        {item.label}
                    </NavLink>
                ))}
            </nav>

            {/* Bouton de déconnexion en bas */}
            <button onClick={handleLogout} style={styles.logoutBtn}>
                🚪 Déconnexion
            </button>
        </aside>
    );
}

// Styles CSS-in-JS (inline styles)
const styles = {
    sidebar:       { width:'240px', minHeight:'100vh', backgroundColor:'#1e293b', color:'white',
                     display:'flex', flexDirection:'column', padding:'0', flexShrink:0 },
    logo:          { display:'flex', alignItems:'center', gap:'10px', padding:'24px 20px',
                     borderBottom:'1px solid #334155' },
    logoIcon:      { fontSize:'24px' },
    logoText:      { fontSize:'18px', fontWeight:'bold', color:'#60a5fa' },
    userInfo:      { display:'flex', alignItems:'center', gap:'12px', padding:'20px',
                     borderBottom:'1px solid #334155' },
    avatar:        { width:'40px', height:'40px', borderRadius:'50%', backgroundColor:'#3b82f6',
                     display:'flex', alignItems:'center', justifyContent:'center',
                     fontWeight:'bold', fontSize:'14px', flexShrink:0 },
    userName:      { fontSize:'14px', fontWeight:'600', marginBottom:'4px' },
    roleBadge:     { fontSize:'11px', padding:'2px 8px', borderRadius:'10px', fontWeight:'500' },
    roleColors:    {
        admin:      { backgroundColor:'#7c3aed', color:'white' },
        enseignant: { backgroundColor:'#059669', color:'white' },
        etudiant:   { backgroundColor:'#2563eb', color:'white' },
    },
    nav:           { flex:1, padding:'12px 0' },
    navLink:       { display:'flex', alignItems:'center', gap:'12px', padding:'12px 20px',
                     color:'#94a3b8', textDecoration:'none', fontSize:'14px',
                     transition:'all 0.2s' },
    navLinkActive: { backgroundColor:'#3b82f6', color:'white', borderRight:'3px solid #60a5fa' },
    navIcon:       { fontSize:'18px', width:'24px', textAlign:'center' },
    logoutBtn:     { margin:'16px', padding:'12px', backgroundColor:'#dc2626', color:'white',
                     border:'none', borderRadius:'8px', cursor:'pointer', fontSize:'14px' },
};

export default Sidebar;
