// ============================================================
// src/pages/Schedule.jsx — Emploi du temps (page commune)
//
// Utilisée par les 3 rôles avec des comportements différents :
//  - Étudiant : voit ses cours inscrits uniquement
//  - Enseignant : voit ses cours assignés uniquement
//  - Admin : voit tout + peut AJOUTER et SUPPRIMER des séances
//
// Navigation par semaine (← Précédente | Suivante →)
// ============================================================

import { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../context/AuthContext';
import api from '../api/axios';

// Plages horaires affichées dans la grille
const HEURES = ['08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00'];
// Noms des jours (index 0 = Lundi)
const JOURS  = ['Lundi','Mardi','Mercredi','Jeudi','Vendredi'];

// Palette de couleurs selon le type de séance
const COULEURS = {
    CM: { bg:'#eff6ff', border:'#3b82f6', text:'#1e40af' }, // bleu
    TD: { bg:'#f0fdf4', border:'#22c55e', text:'#15803d' }, // vert
    TP: { bg:'#fdf4ff', border:'#a855f7', text:'#7e22ce' }, // violet
};

// Obtenir le lundi de la semaine d'une date donnée
function getMonday(d) {
    const date = new Date(d);
    const day  = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1); // dimanche = retour arrière
    return new Date(date.setDate(diff));
}

// Formater une date en YYYY-MM-DD (format ISO pour l'API)
const toISO = (d) => d.toISOString().split('T')[0];

function Schedule() {
    const { user } = useAuth();

    // ---- États de la page ----
    const [seances,      setSeances]      = useState([]);           // toutes les séances chargées
    const [semaine,      setSemaine]      = useState(getMonday(new Date())); // lundi de la semaine affichée
    const [loading,      setLoading]      = useState(true);
    const [etudiantId,   setEtudiantId]   = useState(null);         // pour filtrer les séances étudiant
    const [enseignantId, setEnseignantId] = useState(null);         // pour filtrer les séances enseignant

    // ---- États du formulaire Admin ----
    const [showForm,   setShowForm]   = useState(false);            // afficher/masquer le formulaire
    const [allCours,   setAllCours]   = useState([]);               // liste des cours (pour le select)
    const [formData,   setFormData]   = useState({
        cours_id: '', date_seance: '', heure_debut: '', heure_fin: '', salle: '', type_seance: 'CM',
    });
    const [formError,  setFormError]  = useState('');
    const [formSuccess,setFormSuccess]= useState('');

    // ----------------------------------------------------------------
    // Chargement du profil selon le rôle pour obtenir l'ID de filtre
    // ----------------------------------------------------------------
    useEffect(() => {
        const loadProfile = async () => {
            if (user.role === 'etudiant') {
                const res = await api.get('/students/getAll.php');
                const moi = res.data.find(e => e.email === user.email);
                if (moi) setEtudiantId(moi.id);
            } else if (user.role === 'enseignant') {
                const res = await api.get('/teachers/getAll.php');
                const moi = res.data.find(e => e.email === user.email);
                if (moi) setEnseignantId(moi.id);
            } else if (user.role === 'admin') {
                // L'admin charge aussi la liste des cours pour le formulaire
                const res = await api.get('/courses/getAll.php');
                setAllCours(res.data);
            }
        };
        loadProfile();
    }, [user]);

    // ----------------------------------------------------------------
    // Chargement des séances selon le rôle et les IDs profil
    // ----------------------------------------------------------------
    const fetchSeances = async () => {
        setLoading(true);
        let url = '/schedule/getAll.php';

        // Filtre selon le rôle : étudiant ne voit que ses cours inscrits
        if (user.role === 'etudiant' && etudiantId) {
            url += `?etudiant_id=${etudiantId}`;
        } else if (user.role === 'enseignant' && enseignantId) {
            url += `?enseignant_id=${enseignantId}`;
        }
        // L'admin voit tout (pas de filtre)

        try {
            const res = await api.get(url);
            setSeances(res.data);
        } catch (e) {
            console.error('Erreur chargement emploi du temps:', e);
        } finally {
            setLoading(false);
        }
    };

    // Re-charger les séances quand le profil est disponible
    useEffect(() => {
        if (user.role === 'admin' || etudiantId || enseignantId) {
            fetchSeances();
        }
    }, [user, etudiantId, enseignantId]);

    // ----------------------------------------------------------------
    // Navigation semaine
    // ----------------------------------------------------------------
    const prevWeek = () => setSemaine(d => {
        const n = new Date(d); n.setDate(n.getDate() - 7); return n;
    });
    const nextWeek = () => setSemaine(d => {
        const n = new Date(d); n.setDate(n.getDate() + 7); return n;
    });
    const goToday = () => setSemaine(getMonday(new Date()));

    // Calcule les 5 jours de la semaine affichée (lundi → vendredi)
    const joursSemaine = Array.from({ length: 5 }, (_, i) => {
        const d = new Date(semaine);
        d.setDate(d.getDate() + i);
        return d;
    });

    // Filtre les séances d'un jour donné
    const seancesDuJour = (date) => {
        const dateStr = toISO(date);
        return seances.filter(s => s.date_seance === dateStr)
                      .sort((a, b) => a.heure_debut.localeCompare(b.heure_debut));
    };

    // Formate "08:00:00" → "08:00"
    const fmt = (h) => h?.substring(0, 5) || '';

    // ----------------------------------------------------------------
    // Suppression d'une séance (admin uniquement)
    // ----------------------------------------------------------------
    const handleDelete = async (id, coursNom) => {
        if (!window.confirm(`Supprimer la séance "${coursNom}" ?`)) return;
        try {
            await api.delete(`/schedule/delete.php?id=${id}`);
            setFormSuccess('Séance supprimée.');
            fetchSeances(); // rafraîchit l'emploi du temps
        } catch (err) {
            setFormError(err.response?.data?.error || 'Erreur lors de la suppression');
        }
    };

    // ----------------------------------------------------------------
    // Ajout d'une séance (admin uniquement)
    // ----------------------------------------------------------------
    const handleAddSeance = async (e) => {
        e.preventDefault();
        setFormError(''); setFormSuccess('');
        try {
            await api.post('/schedule/create.php', {
                ...formData,
                cours_id: parseInt(formData.cours_id),
            });
            setFormSuccess('Séance ajoutée avec succès !');
            // Réinitialise le formulaire
            setFormData({ cours_id:'', date_seance:'', heure_debut:'', heure_fin:'', salle:'', type_seance:'CM' });
            setShowForm(false);
            fetchSeances();
        } catch (err) {
            setFormError(err.response?.data?.error || 'Erreur lors de la création');
        }
    };

    const handleFormChange = (e) => {
        setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    return (
        <Layout title="Emploi du temps">

            {/* ---- Barre de navigation semaine ---- */}
            <div style={styles.navBar}>
                <div style={styles.navLeft}>
                    <button onClick={prevWeek} style={styles.navBtn}>← Précédente</button>
                    <button onClick={goToday} style={styles.todayBtn}>Aujourd'hui</button>
                    <button onClick={nextWeek} style={styles.navBtn}>Suivante →</button>
                </div>
                <span style={styles.weekLabel}>
                    📅 Semaine du {semaine.toLocaleDateString('fr-FR', { day:'2-digit', month:'long', year:'numeric' })}
                </span>
                {/* Bouton ajout séance (admin uniquement) */}
                {user.role === 'admin' && (
                    <button onClick={() => setShowForm(p => !p)} style={styles.addBtn}>
                        {showForm ? '✕ Annuler' : '+ Ajouter une séance'}
                    </button>
                )}
            </div>

            {/* ---- Messages flash ---- */}
            {formError   && <div style={styles.errorMsg}>{formError}</div>}
            {formSuccess && <div style={styles.successMsg}>{formSuccess}</div>}

            {/* ---- Formulaire d'ajout (admin) ---- */}
            {user.role === 'admin' && showForm && (
                <div style={styles.formBox}>
                    <h3 style={styles.formTitle}>➕ Nouvelle séance</h3>
                    <form onSubmit={handleAddSeance} style={styles.formGrid}>
                        {/* Sélection du cours */}
                        <div style={styles.formField}>
                            <label style={styles.formLabel}>Cours *</label>
                            <select name="cours_id" value={formData.cours_id} onChange={handleFormChange} required style={styles.formInput}>
                                <option value="">— Choisir un cours —</option>
                                {allCours.map(c => (
                                    <option key={c.id} value={c.id}>{c.code} — {c.nom}</option>
                                ))}
                            </select>
                        </div>

                        {/* Type de séance (CM / TD / TP) */}
                        <div style={styles.formField}>
                            <label style={styles.formLabel}>Type *</label>
                            <select name="type_seance" value={formData.type_seance} onChange={handleFormChange} style={styles.formInput}>
                                <option value="CM">CM — Cours magistral</option>
                                <option value="TD">TD — Travaux dirigés</option>
                                <option value="TP">TP — Travaux pratiques</option>
                            </select>
                        </div>

                        {/* Date */}
                        <div style={styles.formField}>
                            <label style={styles.formLabel}>Date *</label>
                            <input type="date" name="date_seance" value={formData.date_seance} onChange={handleFormChange} required style={styles.formInput} />
                        </div>

                        {/* Heure début */}
                        <div style={styles.formField}>
                            <label style={styles.formLabel}>Heure début *</label>
                            <input type="time" name="heure_debut" value={formData.heure_debut} onChange={handleFormChange} required style={styles.formInput} />
                        </div>

                        {/* Heure fin */}
                        <div style={styles.formField}>
                            <label style={styles.formLabel}>Heure fin *</label>
                            <input type="time" name="heure_fin" value={formData.heure_fin} onChange={handleFormChange} required style={styles.formInput} />
                        </div>

                        {/* Salle */}
                        <div style={styles.formField}>
                            <label style={styles.formLabel}>Salle</label>
                            <input type="text" name="salle" value={formData.salle} onChange={handleFormChange} placeholder="ex: Amphi A, Salle 201..." style={styles.formInput} />
                        </div>

                        {/* Bouton de soumission */}
                        <div style={{ gridColumn:'1 / -1' }}>
                            <button type="submit" style={styles.submitBtn}>
                                ✓ Créer la séance
                            </button>
                        </div>
                    </form>
                </div>
            )}

            {/* ---- Légende des types de séances ---- */}
            <div style={styles.legend}>
                {Object.entries(COULEURS).map(([type, c]) => (
                    <span key={type} style={{
                        ...styles.legendItem,
                        backgroundColor: c.bg,
                        borderLeft: `3px solid ${c.border}`,
                        color: c.text,
                    }}>
                        {type === 'CM' ? '📖 CM' : type === 'TD' ? '✏️ TD' : '🔬 TP'}
                    </span>
                ))}
                <span style={styles.legendInfo}>
                    {seances.length} séance{seances.length > 1 ? 's' : ''} au total
                </span>
            </div>

            {/* ---- Grille de l'emploi du temps ---- */}
            {loading ? (
                <div style={styles.loadingBox}>Chargement de l'emploi du temps...</div>
            ) : (
                <div style={styles.grid}>
                    {joursSemaine.map((jour, i) => {
                        const seancesJour = seancesDuJour(jour);
                        const isToday = toISO(jour) === toISO(new Date());

                        return (
                            <div key={i} style={{
                                ...styles.column,
                                ...(isToday ? styles.todayColumn : {}),
                            }}>
                                {/* En-tête du jour */}
                                <div style={{
                                    ...styles.dayHeader,
                                    ...(isToday ? styles.todayHeader : {}),
                                }}>
                                    <div style={styles.dayName}>{JOURS[i]}</div>
                                    <div style={styles.dayDate}>
                                        {jour.toLocaleDateString('fr-FR', { day:'2-digit', month:'short' })}
                                    </div>
                                    {isToday && <div style={styles.todayBadge}>Aujourd'hui</div>}
                                </div>

                                {/* Séances du jour */}
                                <div style={styles.seancesContainer}>
                                    {seancesJour.length === 0 ? (
                                        <div style={styles.emptyDay}>Libre</div>
                                    ) : seancesJour.map(s => {
                                        const c = COULEURS[s.type_seance] || COULEURS.CM;
                                        return (
                                            <div key={s.id} style={{
                                                ...styles.seanceCard,
                                                backgroundColor: c.bg,
                                                borderLeft: `4px solid ${c.border}`,
                                            }}>
                                                {/* Horaire */}
                                                <div style={{ ...styles.seanceHeure, color: c.text }}>
                                                    🕐 {fmt(s.heure_debut)} – {fmt(s.heure_fin)}
                                                </div>

                                                {/* Nom du cours */}
                                                <div style={styles.seanceNom}>{s.cours_nom}</div>

                                                {/* Infos : type + salle */}
                                                <div style={styles.seanceMeta}>
                                                    <span style={{
                                                        ...styles.typeBadge,
                                                        backgroundColor: c.border,
                                                    }}>
                                                        {s.type_seance}
                                                    </span>
                                                    {s.salle && (
                                                        <span style={styles.salle}>📍 {s.salle}</span>
                                                    )}
                                                </div>

                                                {/* Enseignant (masqué pour l'enseignant lui-même) */}
                                                {user.role !== 'enseignant' && s.enseignant_nom && (
                                                    <div style={styles.seanceEns}>
                                                        👨‍🏫 {s.enseignant_nom}
                                                    </div>
                                                )}

                                                {/* Bouton supprimer (admin uniquement) */}
                                                {user.role === 'admin' && (
                                                    <button
                                                        onClick={() => handleDelete(s.id, s.cours_nom)}
                                                        style={styles.deleteBtn}
                                                        title="Supprimer cette séance"
                                                    >
                                                        🗑️
                                                    </button>
                                                )}
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </Layout>
    );
}

// ---- Styles ----
const styles = {
    navBar:          { display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'16px', backgroundColor:'white', borderRadius:'12px', padding:'14px 20px', boxShadow:'0 1px 3px rgba(0,0,0,0.1)', flexWrap:'wrap', gap:'10px' },
    navLeft:         { display:'flex', gap:'8px' },
    navBtn:          { padding:'8px 14px', backgroundColor:'#f1f5f9', color:'#475569', border:'1px solid #e2e8f0', borderRadius:'8px', cursor:'pointer', fontWeight:'500', fontSize:'13px' },
    todayBtn:        { padding:'8px 14px', backgroundColor:'#eff6ff', color:'#3b82f6', border:'1px solid #bfdbfe', borderRadius:'8px', cursor:'pointer', fontWeight:'600', fontSize:'13px' },
    weekLabel:       { fontWeight:'600', color:'#1e293b', fontSize:'14px' },
    addBtn:          { padding:'9px 18px', backgroundColor:'#3b82f6', color:'white', border:'none', borderRadius:'8px', cursor:'pointer', fontWeight:'600', fontSize:'13px' },
    errorMsg:        { backgroundColor:'#fef2f2', border:'1px solid #fca5a5', color:'#dc2626', padding:'12px 16px', borderRadius:'8px', marginBottom:'12px' },
    successMsg:      { backgroundColor:'#f0fdf4', border:'1px solid #86efac', color:'#16a34a', padding:'12px 16px', borderRadius:'8px', marginBottom:'12px' },

    // Formulaire admin
    formBox:         { backgroundColor:'white', borderRadius:'12px', padding:'24px', marginBottom:'20px', boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    formTitle:       { margin:'0 0 20px', fontSize:'16px', fontWeight:'600', color:'#1e293b' },
    formGrid:        { display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(200px, 1fr))', gap:'16px' },
    formField:       { display:'flex', flexDirection:'column', gap:'6px' },
    formLabel:       { fontSize:'13px', fontWeight:'500', color:'#374151' },
    formInput:       { padding:'9px 12px', border:'1px solid #d1d5db', borderRadius:'8px', fontSize:'14px' },
    submitBtn:       { padding:'11px 24px', backgroundColor:'#10b981', color:'white', border:'none', borderRadius:'8px', cursor:'pointer', fontWeight:'600', fontSize:'14px' },

    // Légende
    legend:          { display:'flex', gap:'10px', marginBottom:'16px', flexWrap:'wrap', alignItems:'center' },
    legendItem:      { padding:'5px 12px', borderRadius:'6px', fontSize:'12px', fontWeight:'600' },
    legendInfo:      { marginLeft:'auto', color:'#94a3b8', fontSize:'13px' },

    // Grille
    loadingBox:      { backgroundColor:'white', borderRadius:'12px', padding:'40px', textAlign:'center', color:'#94a3b8', boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    grid:            { display:'grid', gridTemplateColumns:'repeat(5, 1fr)', gap:'10px' },
    column:          { backgroundColor:'white', borderRadius:'12px', overflow:'hidden', boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    todayColumn:     { boxShadow:'0 0 0 2px #3b82f6' },
    dayHeader:       { padding:'10px', textAlign:'center', borderBottom:'1px solid #f1f5f9', backgroundColor:'#f8fafc' },
    todayHeader:     { backgroundColor:'#eff6ff' },
    dayName:         { fontWeight:'700', fontSize:'12px', color:'#1e293b', textTransform:'uppercase' },
    dayDate:         { fontSize:'11px', color:'#64748b', marginTop:'2px' },
    todayBadge:      { display:'inline-block', backgroundColor:'#3b82f6', color:'white', fontSize:'9px', fontWeight:'700', padding:'2px 6px', borderRadius:'10px', marginTop:'4px' },
    seancesContainer:{ padding:'6px', display:'flex', flexDirection:'column', gap:'6px', minHeight:'200px' },
    emptyDay:        { color:'#cbd5e1', fontSize:'12px', textAlign:'center', padding:'16px 0', fontStyle:'italic' },
    seanceCard:      { borderRadius:'8px', padding:'10px', position:'relative' },
    seanceHeure:     { fontSize:'11px', fontWeight:'700', marginBottom:'4px' },
    seanceNom:       { fontSize:'12px', fontWeight:'600', color:'#1e293b', marginBottom:'5px' },
    seanceMeta:      { display:'flex', alignItems:'center', gap:'6px', marginBottom:'3px', flexWrap:'wrap' },
    typeBadge:       { color:'white', padding:'2px 5px', borderRadius:'3px', fontSize:'9px', fontWeight:'700' },
    salle:           { fontSize:'10px', color:'#64748b' },
    seanceEns:       { fontSize:'10px', color:'#64748b', marginTop:'3px' },
    deleteBtn:       { position:'absolute', top:'6px', right:'6px', background:'none', border:'none', cursor:'pointer', fontSize:'12px', opacity:0.6, padding:'2px 4px', borderRadius:'4px' },
};

export default Schedule;
