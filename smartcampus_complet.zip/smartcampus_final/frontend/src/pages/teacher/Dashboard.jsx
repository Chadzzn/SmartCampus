// ============================================================
// src/pages/teacher/Dashboard.jsx — Dashboard enseignant
// Affiche les cours de l'enseignant connecté et ses stats.
// ============================================================

import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { useAuth } from '../../context/AuthContext';
import api from '../../api/axios';

function TeacherDashboard() {
    const { user } = useAuth(); // récupère l'enseignant connecté
    const [cours, setCours] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Charge tous les cours et filtre côté client pour ceux de cet enseignant
        // Note : en production, on ferait un endpoint dédié côté backend
        api.get('/courses/getAll.php')
            .then(res => {
                // Filtre les cours dont l'enseignant_nom correspond à l'utilisateur connecté
                const mesCours = res.data.filter(c => c.enseignant_nom === `${user.prenom} ${user.nom}`);
                setCours(mesCours);
            })
            .finally(() => setLoading(false));
    }, [user]);

    const totalEtudiants = cours.reduce((sum, c) => sum + c.nb_inscrits, 0);

    return (
        <Layout title={`Bonjour, ${user.prenom} ${user.nom} 👋`}>
            {/* Statistiques de l'enseignant */}
            <div style={styles.statsRow}>
                {[
                    { label:'Mes cours',     value: cours.length,     icon:'📚', color:'#10b981' },
                    { label:'Mes étudiants', value: totalEtudiants,   icon:'🎓', color:'#3b82f6' },
                ].map(s => (
                    <div key={s.label} style={{...styles.statCard, borderLeft:`4px solid ${s.color}`}}>
                        <span style={styles.statIcon}>{s.icon}</span>
                        <div>
                            <div style={{...styles.statValue, color: s.color}}>{s.value}</div>
                            <div style={styles.statLabel}>{s.label}</div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Liste des cours de l'enseignant */}
            <div style={styles.section}>
                <h2 style={styles.sectionTitle}>Mes cours ce semestre</h2>
                {loading ? <p>Chargement...</p> : cours.length === 0 ? (
                    <p style={styles.empty}>Aucun cours assigné pour le moment.</p>
                ) : (
                    <div style={styles.coursGrid}>
                        {cours.map(c => (
                            <div key={c.id} style={styles.coursCard}>
                                <div style={styles.coursCode}>{c.code}</div>
                                <h3 style={styles.coursNom}>{c.nom}</h3>
                                <p style={styles.coursMeta}>
                                    {c.nb_inscrits}/{c.capacite_max} étudiants · {c.semestre}
                                </p>
                                <div style={styles.actions}>
                                    <a href="/enseignant/notes" style={styles.actionLink}>📝 Saisir les notes</a>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </Layout>
    );
}

const styles = {
    statsRow:    { display:'flex', gap:'16px', marginBottom:'32px', flexWrap:'wrap' },
    statCard:    { backgroundColor:'white', borderRadius:'12px', padding:'20px', flex:1, minWidth:'180px',
                   display:'flex', alignItems:'center', gap:'16px', boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    statIcon:    { fontSize:'32px' },
    statValue:   { fontSize:'28px', fontWeight:'bold' },
    statLabel:   { color:'#64748b', fontSize:'13px' },
    section:     { backgroundColor:'white', borderRadius:'12px', padding:'24px', boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    sectionTitle:{ margin:'0 0 20px', fontSize:'18px', fontWeight:'600', color:'#1e293b' },
    empty:       { color:'#94a3b8', textAlign:'center', padding:'20px' },
    coursGrid:   { display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(240px, 1fr))', gap:'16px' },
    coursCard:   { border:'1px solid #e2e8f0', borderRadius:'10px', padding:'16px' },
    coursCode:   { backgroundColor:'#ecfdf5', color:'#059669', display:'inline-block',
                   padding:'3px 8px', borderRadius:'4px', fontSize:'12px', fontWeight:'600', marginBottom:'8px' },
    coursNom:    { margin:'0 0 6px', fontSize:'15px', fontWeight:'600', color:'#1e293b' },
    coursMeta:   { color:'#64748b', fontSize:'13px', margin:'0 0 12px' },
    actions:     { borderTop:'1px solid #f1f5f9', paddingTop:'12px' },
    actionLink:  { color:'#3b82f6', textDecoration:'none', fontSize:'13px' },
};

export default TeacherDashboard;
