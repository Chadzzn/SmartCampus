// ============================================================
// src/pages/teacher/Grades.jsx — Gestion des notes (enseignant)
//
// Fonctionnement :
// 1. L'enseignant choisit un de ses cours dans le menu déroulant
// 2. Tous les étudiants inscrits à ce cours s'affichent
// 3. Pour chacun, l'enseignant peut saisir ou modifier une note
// 4. Les notes verrouillées ne sont plus modifiables
// ============================================================

import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { useAuth } from '../../context/AuthContext';
import api from '../../api/axios';

function TeacherGrades() {
    const { user } = useAuth();

    // Liste des cours de cet enseignant
    const [cours, setCours] = useState([]);
    // Cours actuellement sélectionné dans le menu
    const [selectedCours, setSelectedCours] = useState('');
    // Liste des étudiants + leurs notes pour ce cours
    const [notes, setNotes] = useState([]);
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState('');
    const [error, setError] = useState('');

    // ----------------------------------------------------------------
    // Chargement des cours de l'enseignant connecté
    // On filtre côté client en comparant enseignant_nom avec le profil
    // ----------------------------------------------------------------
    useEffect(() => {
        api.get('/courses/getAll.php').then(res => {
            // Filtre les cours dont le nom d'enseignant correspond
            const mesCours = res.data.filter(
                c => c.enseignant_nom === `${user.prenom} ${user.nom}`
            );
            setCours(mesCours);
        });
    }, [user]);

    // ----------------------------------------------------------------
    // Chargement des étudiants + notes quand un cours est sélectionné
    // Le endpoint getByCourse renvoie TOUS les inscrits (même sans note)
    // ----------------------------------------------------------------
    useEffect(() => {
        if (!selectedCours) {
            setNotes([]); // vide la liste si aucun cours sélectionné
            return;
        }
        setLoading(true);
        api.get(`/grades/getByCourse.php?cours_id=${selectedCours}`)
            .then(res => setNotes(res.data))
            .catch(() => setError('Impossible de charger les notes'))
            .finally(() => setLoading(false));
    }, [selectedCours]);

    // ----------------------------------------------------------------
    // Soumission d'une note pour un étudiant
    // Cette fonction est passée en prop à chaque composant NoteRow
    // ----------------------------------------------------------------
    const handleGradeSubmit = async (etudiantId, note, commentaire) => {
        setError('');
        setSuccess('');
        try {
            await api.post('/grades/setByCourse.php', {
                etudiant_id: etudiantId,
                cours_id:    parseInt(selectedCours),
                note:        parseFloat(note),
                commentaire,
            });
            setSuccess('Note enregistrée avec succès !');

            // Recharger les notes après modification pour afficher l'état à jour
            const res = await api.get(`/grades/getByCourse.php?cours_id=${selectedCours}`);
            setNotes(res.data);
        } catch (err) {
            setError(err.response?.data?.error || 'Erreur lors de la saisie de la note');
        }
    };

    return (
        <Layout title="Gestion des notes">
            {/* Messages d'état */}
            {error && (
                <div style={styles.errorMsg}>{error}</div>
            )}
            {success && (
                <div style={styles.successMsg} onClick={() => setSuccess('')}>
                    {success} <span style={{ cursor:'pointer' }}>✕</span>
                </div>
            )}

            {/* ---- Sélecteur de cours ---- */}
            <div style={styles.selectBox}>
                <label style={styles.label}>Choisir un cours :</label>
                <select
                    value={selectedCours}
                    onChange={e => setSelectedCours(e.target.value)}
                    style={styles.select}
                >
                    <option value="">— Sélectionner un cours —</option>
                    {cours.map(c => (
                        <option key={c.id} value={c.id}>
                            {c.code} — {c.nom}
                        </option>
                    ))}
                </select>
                {selectedCours && (
                    <span style={styles.countBadge}>
                        {notes.length} étudiant{notes.length > 1 ? 's' : ''}
                    </span>
                )}
            </div>

            {/* ---- Tableau des étudiants et notes ---- */}
            {selectedCours && (
                <div style={styles.tableContainer}>
                    {loading ? (
                        <p style={styles.loading}>Chargement des étudiants...</p>
                    ) : notes.length === 0 ? (
                        <p style={styles.empty}>
                            Aucun étudiant inscrit à ce cours.
                        </p>
                    ) : (
                        <table style={styles.table}>
                            <thead>
                                <tr style={styles.thead}>
                                    <th style={styles.th}>N° Étudiant</th>
                                    <th style={styles.th}>Prénom Nom</th>
                                    <th style={styles.th}>Note /20</th>
                                    <th style={styles.th}>Commentaire</th>
                                    <th style={styles.th}>Statut</th>
                                    <th style={styles.th}>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {/* Chaque ligne est un composant indépendant avec son propre état */}
                                {notes.map(n => (
                                    <NoteRow
                                        key={n.etudiant_id}
                                        note={n}
                                        onSave={handleGradeSubmit}
                                    />
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>
            )}

            {/* Message d'invitation si aucun cours sélectionné */}
            {!selectedCours && (
                <div style={styles.placeholder}>
                    <div style={styles.placeholderIcon}>📝</div>
                    <p style={styles.placeholderText}>
                        Sélectionnez un cours pour accéder à la saisie des notes
                    </p>
                </div>
            )}
        </Layout>
    );
}

// ============================================================
// NoteRow — Composant pour une ligne du tableau (un étudiant)
// Gère l'affichage normal et le mode édition de la note.
// ============================================================
function NoteRow({ note, onSave }) {
    // État local de ce composant : est-on en train d'éditer ?
    const [editing,     setEditing]     = useState(false);
    const [noteVal,     setNoteVal]     = useState(note.note ?? '');
    const [commentaire, setCommentaire] = useState(note.commentaire ?? '');

    // Réinitialiser si la note reçue du parent change
    // (utile après la sauvegarde qui recharge les données)
    useEffect(() => {
        setNoteVal(note.note ?? '');
        setCommentaire(note.commentaire ?? '');
        setEditing(false);
    }, [note.note, note.commentaire]);

    // Envoi de la note au parent (TeacherGrades)
    const handleSave = () => {
        if (noteVal === '' || isNaN(noteVal)) return;
        onSave(note.etudiant_id, noteVal, commentaire);
        setEditing(false);
    };

    return (
        <tr style={styles.tr}>
            {/* Numéro étudiant */}
            <td style={styles.td}>
                <code style={styles.numero}>{note.numero}</code>
            </td>

            {/* Identité */}
            <td style={{ ...styles.td, fontWeight: '500' }}>
                {note.prenom} {note.nom}
            </td>

            {/* Champ note (lecture ou édition) */}
            <td style={styles.td}>
                {editing ? (
                    /* Input numérique pour saisir la note (entre 0 et 20) */
                    <input
                        type="number"
                        min="0" max="20" step="0.5"
                        value={noteVal}
                        onChange={e => setNoteVal(e.target.value)}
                        style={{ ...styles.noteInput, width: '80px' }}
                        autoFocus
                    />
                ) : (
                    /* Affichage coloré : vert si ≥ 10, rouge si < 10 */
                    <span style={{
                        fontWeight: '600',
                        color: note.note === null ? '#94a3b8'
                            : note.note >= 10 ? '#16a34a'
                            : '#dc2626',
                    }}>
                        {note.note !== null ? `${note.note}/20` : '—'}
                    </span>
                )}
            </td>

            {/* Champ commentaire (lecture ou édition) */}
            <td style={styles.td}>
                {editing ? (
                    <input
                        value={commentaire}
                        onChange={e => setCommentaire(e.target.value)}
                        style={{ ...styles.noteInput, width: '200px' }}
                        placeholder="Commentaire optionnel..."
                    />
                ) : (
                    <span style={{ color: note.commentaire ? '#374151' : '#cbd5e1' }}>
                        {note.commentaire || '—'}
                    </span>
                )}
            </td>

            {/* Statut de la note (verrouillée ou modifiable) */}
            <td style={styles.td}>
                {note.verrouille
                    ? <span style={styles.locked}>🔒 Verrouillée</span>
                    : note.note !== null
                        ? <span style={styles.editable}>✏️ Modifiable</span>
                        : <span style={styles.missing}>⬜ Non saisie</span>
                }
            </td>

            {/* Boutons d'action */}
            <td style={styles.td}>
                {/* Si la note est verrouillée, on n'affiche rien */}
                {!note.verrouille && (
                    editing ? (
                        /* Mode édition : Sauvegarder ou Annuler */
                        <>
                            <button onClick={handleSave} style={styles.btnSave}>
                                ✓ Enregistrer
                            </button>
                            <button onClick={() => setEditing(false)} style={styles.btnCancel}>
                                ✕
                            </button>
                        </>
                    ) : (
                        /* Mode lecture : bouton pour passer en édition */
                        <button onClick={() => setEditing(true)} style={styles.btnEdit}>
                            {note.note !== null ? '✏️ Modifier' : '+ Saisir'}
                        </button>
                    )
                )}
            </td>
        </tr>
    );
}

// ---- Styles ----
const styles = {
    errorMsg:       { backgroundColor:'#fef2f2', border:'1px solid #fca5a5', color:'#dc2626', padding:'12px 16px', borderRadius:'8px', marginBottom:'16px' },
    successMsg:     { backgroundColor:'#f0fdf4', border:'1px solid #86efac', color:'#16a34a', padding:'12px 16px', borderRadius:'8px', marginBottom:'16px', display:'flex', justifyContent:'space-between', alignItems:'center' },
    selectBox:      { backgroundColor:'white', borderRadius:'12px', padding:'20px 24px', marginBottom:'24px', boxShadow:'0 1px 3px rgba(0,0,0,0.1)', display:'flex', alignItems:'center', gap:'16px', flexWrap:'wrap' },
    label:          { fontSize:'14px', fontWeight:'600', color:'#374151', whiteSpace:'nowrap' },
    select:         { flex:1, minWidth:'250px', padding:'10px 14px', border:'1px solid #d1d5db', borderRadius:'8px', fontSize:'14px', color:'#1e293b' },
    countBadge:     { backgroundColor:'#eff6ff', color:'#2563eb', padding:'6px 14px', borderRadius:'20px', fontSize:'13px', fontWeight:'600', whiteSpace:'nowrap' },
    tableContainer: { backgroundColor:'white', borderRadius:'12px', overflow:'auto', boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    loading:        { padding:'24px', color:'#94a3b8', textAlign:'center' },
    empty:          { padding:'24px', color:'#94a3b8', textAlign:'center' },
    table:          { width:'100%', borderCollapse:'collapse' },
    thead:          { backgroundColor:'#f8fafc' },
    th:             { padding:'12px 16px', textAlign:'left', fontSize:'12px', fontWeight:'600', color:'#64748b', textTransform:'uppercase', letterSpacing:'0.05em', borderBottom:'2px solid #e2e8f0' },
    tr:             { borderBottom:'1px solid #f1f5f9', transition:'background 0.1s' },
    td:             { padding:'14px 16px', fontSize:'14px', color:'#374151' },
    numero:         { backgroundColor:'#f1f5f9', color:'#475569', padding:'3px 8px', borderRadius:'4px', fontSize:'12px', fontFamily:'monospace' },
    noteInput:      { padding:'7px 10px', border:'1px solid #93c5fd', borderRadius:'6px', fontSize:'14px', outline:'none' },
    locked:         { color:'#dc2626', fontSize:'12px', fontWeight:'500' },
    editable:       { color:'#64748b', fontSize:'12px' },
    missing:        { color:'#94a3b8', fontSize:'12px' },
    btnEdit:        { padding:'7px 14px', backgroundColor:'#eff6ff', color:'#3b82f6', border:'1px solid #bfdbfe', borderRadius:'6px', cursor:'pointer', fontSize:'13px', fontWeight:'500' },
    btnSave:        { padding:'7px 12px', backgroundColor:'#f0fdf4', color:'#16a34a', border:'1px solid #bbf7d0', borderRadius:'6px', cursor:'pointer', fontSize:'13px', fontWeight:'500', marginRight:'6px' },
    btnCancel:      { padding:'7px 10px', backgroundColor:'#fef2f2', color:'#dc2626', border:'1px solid #fecaca', borderRadius:'6px', cursor:'pointer', fontSize:'13px' },
    placeholder:    { backgroundColor:'white', borderRadius:'12px', padding:'60px 24px', textAlign:'center', boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    placeholderIcon:{ fontSize:'48px', marginBottom:'12px' },
    placeholderText:{ color:'#94a3b8', fontSize:'16px' },
};

export default TeacherGrades;
