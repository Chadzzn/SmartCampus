// ============================================================
// src/pages/teacher/MyCourses.jsx — Mes cours (enseignant)
// ============================================================

import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { useAuth } from '../../context/AuthContext';
import api from '../../api/axios';

function TeacherCourses() {
    const { user } = useAuth();
    const [cours, setCours] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        api.get('/courses/getAll.php').then(res => {
            setCours(res.data.filter(c => c.enseignant_nom === `${user.prenom} ${user.nom}`));
        }).finally(() => setLoading(false));
    }, [user]);

    return (
        <Layout title="Mes cours">
            {loading ? <p>Chargement...</p> : (
                <div style={styles.grid}>
                    {cours.map(c => (
                        <div key={c.id} style={styles.card}>
                            <div style={styles.header}>
                                <span style={styles.code}>{c.code}</span>
                                <span style={styles.semestre}>{c.semestre}</span>
                            </div>
                            <h3 style={styles.nom}>{c.nom}</h3>
                            <p style={styles.desc}>{c.description || 'Aucune description'}</p>
                            <div style={styles.stats}>
                                <span>🎓 {c.nb_inscrits}/{c.capacite_max} étudiants</span>
                                <span>⭐ {c.credits} crédits</span>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </Layout>
    );
}

const styles = {
    grid: { display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(300px, 1fr))', gap:'20px' },
    card: { backgroundColor:'white', borderRadius:'12px', padding:'24px', boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    header: { display:'flex', justifyContent:'space-between', marginBottom:'12px' },
    code: { backgroundColor:'#ecfdf5', color:'#059669', padding:'4px 10px', borderRadius:'6px', fontSize:'13px', fontWeight:'600' },
    semestre: { color:'#64748b', fontSize:'13px' },
    nom: { margin:'0 0 8px', fontSize:'17px', fontWeight:'600', color:'#1e293b' },
    desc: { color:'#64748b', fontSize:'14px', margin:'0 0 16px' },
    stats: { display:'flex', gap:'16px', color:'#64748b', fontSize:'13px', borderTop:'1px solid #f1f5f9', paddingTop:'12px' },
};

export default TeacherCourses;
