// ============================================================
// src/pages/student/MyCourses.jsx — Mes cours (étudiant)
//
// Fonctionnalités :
//  - Voir ses cours inscrits (avec notes si disponibles)
//  - Se désinscrire d'un cours (bouton "Quitter")
//  - Consulter le catalogue des cours disponibles
//  - S'inscrire à un nouveau cours (avec vérif capacité)
// ============================================================

import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { useAuth } from '../../context/AuthContext';
import api from '../../api/axios';

function StudentCourses() {
    const { user } = useAuth();

    const [etudiantId,    setEtudiantId]    = useState(null);
    const [mesCours,      setMesCours]      = useState([]);   // cours auxquels je suis inscrit
    const [tousLesCours,  setTousLesCours]  = useState([]);   // catalogue complet
    const [showCatalogue, setShowCatalogue] = useState(false);// affichage catalogue toggle
    const [loading,       setLoading]       = useState(true);
    const [error,         setError]         = useState('');
    const [success,       setSuccess]       = useState('');

    // ----------------------------------------------------------------
    // Chargement des données (mes cours + catalogue)
    // ----------------------------------------------------------------
    const fetchData = async (eid) => {
        // On lance les deux requêtes en parallèle pour gagner du temps
        const [inscrits, tous] = await Promise.all([
            api.get(`/enrollments/getByStudent.php?etudiant_id=${eid}`),
            api.get('/courses/getAll.php'),
        ]);
        setMesCours(inscrits.data);
        setTousLesCours(tous.data);
    };

    // Au montage : trouver l'ID étudiant via l'email de l'utilisateur connecté
    useEffect(() => {
        api.get('/students/getAll.php')
            .then(res => {
                const moi = res.data.find(e => e.email === user.email);
                if (moi) {
                    setEtudiantId(moi.id);
                    return fetchData(moi.id);
                }
            })
            .finally(() => setLoading(false));
    }, [user]);

    // ----------------------------------------------------------------
    // Inscription à un cours
    // ----------------------------------------------------------------
    const handleInscrire = async (coursId) => {
        setError(''); setSuccess('');
        try {
            await api.post('/enrollments/enroll.php', {
                etudiant_id: etudiantId,
                cours_id:    coursId,
            });
            setSuccess('Inscription réussie ! Le cours a été ajouté à votre liste.');
            await fetchData(etudiantId); // rafraîchit les deux listes
        } catch (err) {
            setError(err.response?.data?.error || 'Erreur lors de l\'inscription');
        }
    };

    // ----------------------------------------------------------------
    // Désinscription d'un cours
    // Une confirmation est demandée avant de supprimer l'inscription
    // ----------------------------------------------------------------
    const handleDesinscrire = async (coursId, nomCours) => {
        // Confirmation native du navigateur avant action irréversible
        if (!window.confirm(`Se désinscrire du cours "${nomCours}" ?`)) return;
        setError(''); setSuccess('');
        try {
            await api.delete(`/enrollments/unenroll.php?etudiant_id=${etudiantId}&cours_id=${coursId}`);
            setSuccess('Désinscription effectuée.');
            await fetchData(etudiantId);
        } catch (err) {
            setError(err.response?.data?.error || 'Erreur lors de la désinscription');
        }
    };

    // Ensemble des IDs de mes cours actuels (pour filtrer le catalogue)
    const coursInscritsIds = new Set(mesCours.map(c => c.cours_id));

    // Catalogue = cours auxquels je ne suis PAS encore inscrit
    const coursDisponibles = tousLesCours.filter(c => !coursInscritsIds.has(c.id));

    return (
        <Layout title="Mes cours">
            {/* Messages flash */}
            {error   && <div style={styles.errorMsg}>{error}</div>}
            {success && <div style={styles.successMsg}>{success}</div>}

            {/* ---- SECTION : Mes inscriptions actuelles ---- */}
            <div style={styles.section}>
                <h2 style={styles.sectionTitle}>
                    📚 Mes inscriptions ({mesCours.length})
                </h2>

                {loading ? (
                    <p style={styles.loading}>Chargement...</p>
                ) : mesCours.length === 0 ? (
                    <p style={styles.empty}>
                        Vous n'êtes inscrit à aucun cours.
                        Consultez le catalogue ci-dessous pour vous inscrire.
                    </p>
                ) : (
                    <div style={styles.grid}>
                        {mesCours.map(c => (
                            <div key={c.inscription_id} style={styles.card}>
                                {/* En-tête de la carte */}
                                <div style={styles.cardHeader}>
                                    <span style={styles.code}>{c.code}</span>
                                    <span style={styles.semestre}>{c.semestre}</span>
                                </div>

                                {/* Nom et enseignant */}
                                <h3 style={styles.nom}>{c.nom}</h3>
                                <p style={styles.meta}>
                                    👨‍🏫 {c.enseignant_nom || 'N/A'} · ⭐ {c.credits} crédits
                                </p>

                                {/* Affichage de la note si disponible */}
                                <div style={styles.noteBox}>
                                    {c.note !== null ? (
                                        <span style={{
                                            ...styles.note,
                                            // Couleur selon réussite ou échec
                                            color:           c.note >= 10 ? '#16a34a' : '#dc2626',
                                            backgroundColor: c.note >= 10 ? '#f0fdf4' : '#fef2f2',
                                        }}>
                                            Note : {c.note}/20
                                        </span>
                                    ) : (
                                        <span style={styles.noNote}>Note non disponible</span>
                                    )}
                                </div>

                                {/* Bouton désinscription — désactivé si note présente */}
                                {c.note === null ? (
                                    <button
                                        onClick={() => handleDesinscrire(c.cours_id, c.nom)}
                                        style={styles.unenrollBtn}
                                    >
                                        Quitter ce cours
                                    </button>
                                ) : (
                                    <p style={styles.cantUnenroll}>
                                        (Désinscription impossible après notation)
                                    </p>
                                )}
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* ---- SECTION : Catalogue des cours disponibles ---- */}
            <div style={styles.section}>
                {/* En-tête avec bouton toggle */}
                <div style={styles.catalogueHeader}>
                    <h2 style={styles.sectionTitle}>
                        🔍 Catalogue ({coursDisponibles.length} cours disponibles)
                    </h2>
                    <button
                        onClick={() => setShowCatalogue(p => !p)}
                        style={styles.toggleBtn}
                    >
                        {showCatalogue ? '▲ Masquer' : '▼ Afficher'}
                    </button>
                </div>

                {/* Catalogue déroulable */}
                {showCatalogue && (
                    coursDisponibles.length === 0 ? (
                        <p style={styles.empty}>Vous êtes inscrit à tous les cours disponibles !</p>
                    ) : (
                        <div style={styles.grid}>
                            {coursDisponibles.map(c => {
                                const complet = c.nb_inscrits >= c.capacite_max;
                                return (
                                    <div key={c.id} style={{
                                        ...styles.card,
                                        opacity: complet ? 0.65 : 1,
                                    }}>
                                        <div style={styles.cardHeader}>
                                            <span style={styles.code}>{c.code}</span>
                                            {/* Indicateur de capacité */}
                                            <span style={{
                                                ...styles.capacite,
                                                color: complet ? '#dc2626' : '#16a34a',
                                            }}>
                                                {c.nb_inscrits}/{c.capacite_max} places
                                            </span>
                                        </div>
                                        <h3 style={styles.nom}>{c.nom}</h3>
                                        <p style={styles.meta}>
                                            👨‍🏫 {c.enseignant_nom || 'N/A'} · ⭐ {c.credits} crédits · {c.semestre}
                                        </p>
                                        {c.description && (
                                            <p style={styles.desc}>{c.description}</p>
                                        )}
                                        {/* Bouton inscription — désactivé si cours complet */}
                                        <button
                                            onClick={() => handleInscrire(c.id)}
                                            disabled={complet}
                                            style={{
                                                ...styles.enrollBtn,
                                                ...(complet ? styles.enrollBtnDisabled : {}),
                                            }}
                                        >
                                            {complet ? '🔒 Cours complet' : '+ S\'inscrire'}
                                        </button>
                                    </div>
                                );
                            })}
                        </div>
                    )
                )}
            </div>
        </Layout>
    );
}

// ---- Styles ----
const styles = {
    errorMsg:        { backgroundColor:'#fef2f2', border:'1px solid #fca5a5', color:'#dc2626', padding:'12px 16px', borderRadius:'8px', marginBottom:'16px' },
    successMsg:      { backgroundColor:'#f0fdf4', border:'1px solid #86efac', color:'#16a34a', padding:'12px 16px', borderRadius:'8px', marginBottom:'16px' },
    loading:         { color:'#94a3b8', padding:'12px 0' },
    section:         { backgroundColor:'white', borderRadius:'12px', padding:'24px', marginBottom:'20px', boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    sectionTitle:    { margin:'0 0 16px', fontSize:'17px', fontWeight:'600', color:'#1e293b' },
    catalogueHeader: { display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'16px' },
    toggleBtn:       { padding:'8px 16px', backgroundColor:'#eff6ff', color:'#3b82f6', border:'1px solid #bfdbfe', borderRadius:'8px', cursor:'pointer', fontWeight:'500', fontSize:'14px' },
    empty:           { color:'#94a3b8', padding:'12px 0', fontSize:'14px' },
    grid:            { display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(260px, 1fr))', gap:'16px' },
    card:            { border:'1px solid #e2e8f0', borderRadius:'10px', padding:'16px', display:'flex', flexDirection:'column', gap:'8px' },
    cardHeader:      { display:'flex', justifyContent:'space-between', alignItems:'center' },
    code:            { backgroundColor:'#eff6ff', color:'#2563eb', padding:'3px 8px', borderRadius:'4px', fontSize:'12px', fontWeight:'600' },
    semestre:        { color:'#94a3b8', fontSize:'12px' },
    capacite:        { fontSize:'12px', fontWeight:'500' },
    nom:             { margin:'0', fontSize:'15px', fontWeight:'600', color:'#1e293b' },
    meta:            { color:'#64748b', fontSize:'12px', margin:'0' },
    desc:            { color:'#94a3b8', fontSize:'12px', margin:'0', fontStyle:'italic' },
    noteBox:         { borderTop:'1px solid #f1f5f9', paddingTop:'8px', marginTop:'4px' },
    note:            { padding:'4px 10px', borderRadius:'20px', fontSize:'13px', fontWeight:'600' },
    noNote:          { color:'#94a3b8', fontSize:'12px' },
    unenrollBtn:     { marginTop:'4px', width:'100%', padding:'8px', backgroundColor:'#fef2f2', color:'#dc2626', border:'1px solid #fecaca', borderRadius:'7px', cursor:'pointer', fontSize:'13px', fontWeight:'500' },
    cantUnenroll:    { color:'#94a3b8', fontSize:'11px', textAlign:'center', margin:'4px 0 0', fontStyle:'italic' },
    enrollBtn:       { marginTop:'4px', width:'100%', padding:'10px', backgroundColor:'#3b82f6', color:'white', border:'none', borderRadius:'8px', cursor:'pointer', fontWeight:'500', fontSize:'14px' },
    enrollBtnDisabled: { backgroundColor:'#e2e8f0', color:'#94a3b8', cursor:'not-allowed' },
};

export default StudentCourses;
