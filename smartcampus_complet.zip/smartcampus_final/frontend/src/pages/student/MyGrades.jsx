// ============================================================
// src/pages/student/MyGrades.jsx — Mes notes (étudiant)
// Affiche toutes les notes de l'étudiant avec la moyenne
// générale et un indicateur de réussite par cours.
// ============================================================

import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { useAuth } from '../../context/AuthContext';
import api from '../../api/axios';

function StudentGrades() {
    const { user } = useAuth();
    const [inscriptions, setInscriptions] = useState([]);
    const [loading,      setLoading]      = useState(true);

    useEffect(() => {
        api.get('/students/getAll.php').then(res => {
            const moi = res.data.find(e => e.email === user.email);
            if (moi) {
                return api.get(`/enrollments/getByStudent.php?etudiant_id=${moi.id}`);
            }
        }).then(res => {
            if (res) setInscriptions(res.data);
        }).finally(() => setLoading(false));
    }, [user]);

    // Calculs statistiques
    const notesValides  = inscriptions.filter(i => i.note !== null);
    const moyenne       = notesValides.length > 0
        ? (notesValides.reduce((sum, i) => sum + parseFloat(i.note), 0) / notesValides.length).toFixed(2)
        : null;
    const totalCredits  = inscriptions.reduce((sum, i) => sum + (i.credits || 0), 0);
    const creditsValides = notesValides.filter(i => i.note >= 10).reduce((sum, i) => sum + (i.credits || 0), 0);

    // Détermine la couleur d'une note
    const noteColor = (note) => {
        if (note === null) return { bg:'#f8fafc', text:'#94a3b8' };
        if (note >= 14)    return { bg:'#f0fdf4', text:'#15803d' }; // Bien / TB
        if (note >= 10)    return { bg:'#eff6ff', text:'#1d4ed8' }; // Passable
        return              { bg:'#fef2f2', text:'#dc2626' };        // Insuffisant
    };

    // Mention selon la moyenne
    const getMention = (m) => {
        if (!m) return null;
        const n = parseFloat(m);
        if (n >= 16) return { label:'Très bien', color:'#15803d' };
        if (n >= 14) return { label:'Bien',       color:'#16a34a' };
        if (n >= 12) return { label:'Assez bien', color:'#0369a1' };
        if (n >= 10) return { label:'Passable',   color:'#1d4ed8' };
        return             { label:'Insuffisant', color:'#dc2626' };
    };

    const mention = getMention(moyenne);

    return (
        <Layout title="Mes notes">
            {loading ? <p>Chargement...</p> : (
                <>
                    {/* Résumé en haut */}
                    <div style={styles.summaryGrid}>
                        <div style={styles.summaryCard}>
                            <div style={styles.summaryLabel}>Moyenne générale</div>
                            <div style={{
                                ...styles.summaryValue,
                                color: moyenne && parseFloat(moyenne) >= 10 ? '#16a34a' : '#dc2626'
                            }}>
                                {moyenne ? `${moyenne}/20` : '—'}
                            </div>
                            {mention && (
                                <span style={{...styles.mention, color: mention.color}}>
                                    {mention.label}
                                </span>
                            )}
                        </div>
                        <div style={styles.summaryCard}>
                            <div style={styles.summaryLabel}>Crédits validés</div>
                            <div style={styles.summaryValue}>{creditsValides}/{totalCredits}</div>
                            <div style={styles.summaryMeta}>ECTS</div>
                        </div>
                        <div style={styles.summaryCard}>
                            <div style={styles.summaryLabel}>Cours notés</div>
                            <div style={styles.summaryValue}>{notesValides.length}/{inscriptions.length}</div>
                            <div style={styles.summaryMeta}>matières</div>
                        </div>
                    </div>

                    {/* Tableau des notes */}
                    <div style={styles.tableContainer}>
                        <table style={styles.table}>
                            <thead>
                                <tr style={styles.thead}>
                                    {['Code','Cours','Enseignant','Crédits','Note','Résultat'].map(h => (
                                        <th key={h} style={styles.th}>{h}</th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {inscriptions.map(i => {
                                    const colors = noteColor(i.note);
                                    return (
                                        <tr key={i.inscription_id} style={styles.tr}>
                                            <td style={styles.td}>
                                                <span style={styles.code}>{i.code}</span>
                                            </td>
                                            <td style={{...styles.td, fontWeight:'500'}}>{i.nom}</td>
                                            <td style={styles.td}>{i.enseignant_nom || '—'}</td>
                                            <td style={{...styles.td, textAlign:'center'}}>{i.credits}</td>
                                            <td style={styles.td}>
                                                {/* Badge de note coloré */}
                                                <span style={{
                                                    backgroundColor: colors.bg,
                                                    color: colors.text,
                                                    padding:'5px 12px',
                                                    borderRadius:'20px',
                                                    fontWeight:'600',
                                                    fontSize:'14px',
                                                }}>
                                                    {i.note !== null ? `${i.note}/20` : 'N/A'}
                                                </span>
                                            </td>
                                            <td style={styles.td}>
                                                {/* Icône de résultat */}
                                                {i.note === null   ? <span style={styles.pending}>⏳ En attente</span>
                                                : i.note >= 10     ? <span style={styles.passed}>✅ Validé</span>
                                                :                    <span style={styles.failed}>❌ Ajourné</span>}
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                </>
            )}
        </Layout>
    );
}

const styles = {
    summaryGrid:    { display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(180px, 1fr))', gap:'16px', marginBottom:'24px' },
    summaryCard:    { backgroundColor:'white', borderRadius:'12px', padding:'24px', textAlign:'center', boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    summaryLabel:   { fontSize:'13px', color:'#64748b', marginBottom:'8px' },
    summaryValue:   { fontSize:'32px', fontWeight:'bold', color:'#1e293b', marginBottom:'4px' },
    summaryMeta:    { fontSize:'12px', color:'#94a3b8' },
    mention:        { fontSize:'13px', fontWeight:'600' },
    tableContainer: { backgroundColor:'white', borderRadius:'12px', overflow:'hidden', boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    table:          { width:'100%', borderCollapse:'collapse' },
    thead:          { backgroundColor:'#f8fafc' },
    th:             { padding:'12px 16px', textAlign:'left', fontSize:'12px', fontWeight:'600', color:'#64748b', textTransform:'uppercase', borderBottom:'1px solid #e2e8f0' },
    tr:             { borderBottom:'1px solid #f1f5f9' },
    td:             { padding:'14px 16px', fontSize:'14px', color:'#374151' },
    code:           { backgroundColor:'#eff6ff', color:'#2563eb', padding:'3px 8px', borderRadius:'4px', fontSize:'12px', fontWeight:'600' },
    pending:        { color:'#92400e', fontSize:'13px' },
    passed:         { color:'#15803d', fontSize:'13px' },
    failed:         { color:'#dc2626', fontSize:'13px' },
};

export default StudentGrades;
