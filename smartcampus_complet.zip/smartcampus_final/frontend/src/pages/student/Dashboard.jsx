// ============================================================
// src/pages/student/Dashboard.jsx — Tableau de bord étudiant
// L'étudiant voit ses cours inscrits, sa moyenne générale
// et un résumé de ses notes.
// ============================================================

import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { useAuth } from '../../context/AuthContext';
import api from '../../api/axios';

function StudentDashboard() {
    const { user } = useAuth();
    const [inscriptions, setInscriptions] = useState([]);
    const [loading,      setLoading]      = useState(true);
    const [etudiantId,   setEtudiantId]   = useState(null);

    useEffect(() => {
        // Étape 1 : récupérer le profil étudiant pour avoir son ID interne
        api.get('/students/getAll.php').then(res => {
            // On cherche l'étudiant dont l'email correspond à l'utilisateur connecté
            const moi = res.data.find(e => e.email === user.email);
            if (moi) {
                setEtudiantId(moi.id);
                // Étape 2 : charger ses inscriptions et notes
                return api.get(`/enrollments/getByStudent.php?etudiant_id=${moi.id}`);
            }
        }).then(res => {
            if (res) setInscriptions(res.data);
        }).finally(() => setLoading(false));
    }, [user]);

    // Calcul de la moyenne générale (seulement sur les cours ayant une note)
    const notesValides = inscriptions.filter(i => i.note !== null);
    const moyenne = notesValides.length > 0
        ? (notesValides.reduce((sum, i) => sum + parseFloat(i.note), 0) / notesValides.length).toFixed(2)
        : null;

    return (
        <Layout title={`Bonjour, ${user.prenom} ${user.nom} 👋`}>
            {/* Cartes de statistiques */}
            <div style={styles.statsRow}>
                {[
                    { label:'Cours inscrits',  value: inscriptions.length, icon:'📚', color:'#3b82f6' },
                    { label:'Notes disponibles', value: notesValides.length, icon:'📊', color:'#8b5cf6' },
                    { label:'Moyenne générale', value: moyenne ? `${moyenne}/20` : '—', icon:'⭐', color:'#f59e0b' },
                ].map(s => (
                    <div key={s.label} style={{...styles.statCard, borderTop:`3px solid ${s.color}`}}>
                        <span style={styles.statIcon}>{s.icon}</span>
                        <div>
                            <div style={{...styles.statValue, color: s.color}}>{s.value}</div>
                            <div style={styles.statLabel}>{s.label}</div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Résumé des cours et notes */}
            <div style={styles.section}>
                <h2 style={styles.sectionTitle}>Mes cours en cours</h2>
                {loading ? <p>Chargement...</p> : inscriptions.length === 0 ? (
                    <p style={styles.empty}>Vous n'êtes inscrit à aucun cours.</p>
                ) : (
                    <div style={styles.grid}>
                        {inscriptions.map(i => (
                            <div key={i.inscription_id} style={styles.card}>
                                <div style={styles.cardTop}>
                                    <span style={styles.code}>{i.code}</span>
                                    {/* Affiche la note avec couleur (vert ≥ 10, rouge < 10) */}
                                    {i.note !== null ? (
                                        <span style={{
                                            ...styles.noteBadge,
                                            backgroundColor: i.note >= 10 ? '#f0fdf4' : '#fef2f2',
                                            color:           i.note >= 10 ? '#16a34a' : '#dc2626',
                                        }}>
                                            {i.note}/20
                                        </span>
                                    ) : (
                                        <span style={styles.noBadge}>En attente</span>
                                    )}
                                </div>
                                <h3 style={styles.coursNom}>{i.nom}</h3>
                                <p style={styles.meta}>👨‍🏫 {i.enseignant_nom || 'N/A'} · {i.semestre}</p>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </Layout>
    );
}

const styles = {
    statsRow:    { display:'flex', gap:'16px', marginBottom:'32px', flexWrap:'wrap' },
    statCard:    { backgroundColor:'white', borderRadius:'12px', padding:'24px', flex:1, minWidth:'160px',
                   display:'flex', alignItems:'center', gap:'16px', boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    statIcon:    { fontSize:'32px' },
    statValue:   { fontSize:'26px', fontWeight:'bold' },
    statLabel:   { color:'#64748b', fontSize:'13px', marginTop:'2px' },
    section:     { backgroundColor:'white', borderRadius:'12px', padding:'24px', boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    sectionTitle:{ margin:'0 0 20px', fontSize:'18px', fontWeight:'600', color:'#1e293b' },
    empty:       { color:'#94a3b8', textAlign:'center', padding:'20px' },
    grid:        { display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(240px, 1fr))', gap:'16px' },
    card:        { border:'1px solid #e2e8f0', borderRadius:'10px', padding:'16px' },
    cardTop:     { display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'10px' },
    code:        { backgroundColor:'#eff6ff', color:'#2563eb', padding:'3px 8px', borderRadius:'4px', fontSize:'12px', fontWeight:'600' },
    noteBadge:   { padding:'4px 10px', borderRadius:'20px', fontSize:'13px', fontWeight:'600' },
    noBadge:     { backgroundColor:'#f8fafc', color:'#94a3b8', padding:'4px 10px', borderRadius:'20px', fontSize:'12px' },
    coursNom:    { margin:'0 0 6px', fontSize:'15px', fontWeight:'600', color:'#1e293b' },
    meta:        { color:'#64748b', fontSize:'12px', margin:0 },
};

export default StudentDashboard;
