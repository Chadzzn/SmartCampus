// ============================================================
// src/pages/Login.jsx — Page de connexion
// C'est la première page que voit l'utilisateur.
// Après connexion, il est redirigé vers son dashboard selon son rôle.
// ============================================================

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function Login() {
    // useState crée une variable réactive : quand elle change, React re-rend le composant
    const [email,    setEmail]    = useState('');
    const [password, setPassword] = useState('');
    const [error,    setError]    = useState('');        // message d'erreur à afficher
    const [loading,  setLoading]  = useState(false);    // désactive le bouton pendant la requête

    const { login } = useAuth();       // fonction login du contexte
    const navigate  = useNavigate();   // fonction pour changer de page

    // --- Gestion de la soumission du formulaire ---
    const handleSubmit = async (e) => {
        e.preventDefault(); // empêche le rechargement de la page (comportement HTML par défaut)
        setError('');        // effacement de l'erreur précédente
        setLoading(true);

        try {
            // Appel à l'API via le contexte
            const user = await login(email, password);

            // Redirection selon le rôle de l'utilisateur
            const redirects = {
                admin:      '/admin',
                enseignant: '/enseignant',
                etudiant:   '/etudiant',
            };
            navigate(redirects[user.role] || '/login');

        } catch (err) {
            // Si le backend retourne une erreur, on l'affiche
            setError(err.response?.data?.error || 'Erreur de connexion');
        } finally {
            setLoading(false); // toujours réactiver le bouton à la fin
        }
    };

    return (
        <div style={styles.container}>
            {/* Carte de connexion centrée */}
            <div style={styles.card}>
                {/* En-tête */}
                <div style={styles.header}>
                    <div style={styles.logo}>🎓</div>
                    <h1 style={styles.title}>SmartCampus</h1>
                    <p style={styles.subtitle}>Plateforme de gestion académique</p>
                </div>

                {/* Formulaire */}
                <form onSubmit={handleSubmit} style={styles.form}>
                    {/* Affichage du message d'erreur si besoin */}
                    {error && <div style={styles.errorBox}>{error}</div>}

                    {/* Champ Email */}
                    <div style={styles.field}>
                        <label style={styles.label}>Email</label>
                        <input
                            type="email"
                            value={email}
                            onChange={e => setEmail(e.target.value)} // mise à jour à chaque frappe
                            placeholder="votre@email.fr"
                            required
                            style={styles.input}
                        />
                    </div>

                    {/* Champ Mot de passe */}
                    <div style={styles.field}>
                        <label style={styles.label}>Mot de passe</label>
                        <input
                            type="password"
                            value={password}
                            onChange={e => setPassword(e.target.value)}
                            placeholder="••••••••"
                            required
                            style={styles.input}
                        />
                    </div>

                    {/* Bouton de connexion */}
                    <button
                        type="submit"
                        disabled={loading} // désactivé pendant le chargement
                        style={{...styles.btn, ...(loading ? styles.btnDisabled : {})}}
                    >
                        {loading ? 'Connexion...' : 'Se connecter'}
                    </button>
                </form>

                {/* Comptes de test (utile pendant le développement) */}
                <div style={styles.testAccounts}>
                    <p style={styles.testTitle}>Comptes de test (mot de passe: <code>password</code>)</p>
                    <div style={styles.testGrid}>
                        <div onClick={() => { setEmail('admin@smartcampus.fr'); setPassword('password'); }} style={styles.testBtn}>
                            👑 Admin
                        </div>
                        <div onClick={() => { setEmail('mdupont@smartcampus.fr'); setPassword('password'); }} style={styles.testBtn}>
                            👨‍🏫 Enseignant
                        </div>
                        <div onClick={() => { setEmail('lbernard@smartcampus.fr'); setPassword('password'); }} style={styles.testBtn}>
                            🎓 Étudiant
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

const styles = {
    container:    { minHeight:'100vh', backgroundColor:'#0f172a', display:'flex',
                    alignItems:'center', justifyContent:'center', padding:'20px' },
    card:         { backgroundColor:'white', borderRadius:'16px', padding:'40px',
                    width:'100%', maxWidth:'420px', boxShadow:'0 25px 50px rgba(0,0,0,0.5)' },
    header:       { textAlign:'center', marginBottom:'32px' },
    logo:         { fontSize:'48px', marginBottom:'12px' },
    title:        { fontSize:'28px', fontWeight:'bold', color:'#1e293b', margin:'0 0 4px' },
    subtitle:     { color:'#64748b', fontSize:'14px', margin:0 },
    form:         { display:'flex', flexDirection:'column', gap:'16px' },
    errorBox:     { backgroundColor:'#fef2f2', border:'1px solid #fca5a5', color:'#dc2626',
                    padding:'12px', borderRadius:'8px', fontSize:'14px' },
    field:        { display:'flex', flexDirection:'column', gap:'6px' },
    label:        { fontSize:'14px', fontWeight:'500', color:'#374151' },
    input:        { padding:'12px', border:'1px solid #d1d5db', borderRadius:'8px',
                    fontSize:'14px', outline:'none' },
    btn:          { padding:'14px', backgroundColor:'#3b82f6', color:'white', border:'none',
                    borderRadius:'8px', fontSize:'16px', fontWeight:'600', cursor:'pointer' },
    btnDisabled:  { backgroundColor:'#93c5fd', cursor:'not-allowed' },
    testAccounts: { marginTop:'24px', padding:'16px', backgroundColor:'#f8fafc',
                    borderRadius:'8px', border:'1px solid #e2e8f0' },
    testTitle:    { fontSize:'12px', color:'#64748b', marginBottom:'8px', textAlign:'center' },
    testGrid:     { display:'flex', gap:'8px' },
    testBtn:      { flex:1, padding:'8px', backgroundColor:'white', border:'1px solid #e2e8f0',
                    borderRadius:'6px', fontSize:'12px', textAlign:'center', cursor:'pointer' },
};

export default Login;
