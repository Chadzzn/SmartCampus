// ============================================================
// src/pages/admin/Students.jsx — Gestion des étudiants
// Fonctionnalités : liste, ajout, modification, suppression
// C'est un exemple de CRUD complet côté React.
// ============================================================

import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import api from '../../api/axios';

function AdminStudents() {
    const [etudiants, setEtudiants] = useState([]);    // liste des étudiants
    const [loading,   setLoading]   = useState(true);
    const [error,     setError]     = useState('');
    const [success,   setSuccess]   = useState('');

    // State pour le formulaire (ajout / modification)
    const [showForm,    setShowForm]    = useState(false);
    const [editingId,   setEditingId]   = useState(null);  // null = ajout, ID = modification
    const [formData,    setFormData]    = useState({
        nom: '', prenom: '', email: '', password: '',
        numero: '', promotion: '', groupe: ''
    });

    // Chargement de la liste des étudiants
    const fetchEtudiants = async () => {
        try {
            const res = await api.get('/students/getAll.php');
            setEtudiants(res.data);
        } catch (err) {
            setError('Impossible de charger les étudiants');
        } finally {
            setLoading(false);
        }
    };

    // S'exécute au montage ET chaque fois qu'on a besoin de rafraîchir
    useEffect(() => { fetchEtudiants(); }, []);

    // --- Gestion du formulaire ---
    // Met à jour le champ modifié dans formData
    const handleChange = (e) => {
        setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    // Ouvre le formulaire en mode "modification" avec les données existantes
    const handleEdit = (etudiant) => {
        setEditingId(etudiant.id);
        setFormData({
            nom:       etudiant.nom,
            prenom:    etudiant.prenom,
            email:     etudiant.email,
            password:  '', // on ne pré-remplit jamais le mot de passe
            numero:    etudiant.numero,
            promotion: etudiant.promotion || '',
            groupe:    etudiant.groupe || '',
        });
        setShowForm(true);
    };

    // Ouvre le formulaire en mode "ajout" (réinitialise)
    const handleNew = () => {
        setEditingId(null);
        setFormData({ nom:'', prenom:'', email:'', password:'', numero:'', promotion:'', groupe:'' });
        setShowForm(true);
    };

    // Soumission du formulaire (ajout ou modification)
    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        try {
            if (editingId) {
                // Mode modification
                await api.put(`/students/update.php?id=${editingId}`, formData);
                setSuccess('Étudiant modifié avec succès');
            } else {
                // Mode ajout
                await api.post('/students/create.php', formData);
                setSuccess('Étudiant créé avec succès');
            }
            setShowForm(false);
            fetchEtudiants(); // on recharge la liste après modification
        } catch (err) {
            setError(err.response?.data?.error || 'Erreur lors de la sauvegarde');
        }
    };

    // Suppression d'un étudiant avec confirmation
    const handleDelete = async (id, nom) => {
        // window.confirm affiche une boîte de dialogue native du navigateur
        if (!window.confirm(`Supprimer l'étudiant ${nom} ? Cette action est irréversible.`)) return;
        try {
            await api.delete(`/students/delete.php?id=${id}`);
            setSuccess('Étudiant supprimé');
            fetchEtudiants();
        } catch (err) {
            setError(err.response?.data?.error || 'Erreur lors de la suppression');
        }
    };

    return (
        <Layout title="Gestion des étudiants">
            {/* Messages de retour */}
            {error   && <div style={styles.errorMsg}>{error}</div>}
            {success && <div style={styles.successMsg}>{success}</div>}

            {/* Barre d'actions */}
            <div style={styles.toolbar}>
                <p style={styles.count}>{etudiants.length} étudiant(s)</p>
                <button onClick={handleNew} style={styles.btnPrimary}>+ Ajouter un étudiant</button>
            </div>

            {/* Formulaire d'ajout/modification (affichage conditionnel) */}
            {showForm && (
                <div style={styles.formCard}>
                    <h3 style={styles.formTitle}>
                        {editingId ? 'Modifier l\'étudiant' : 'Ajouter un étudiant'}
                    </h3>
                    <form onSubmit={handleSubmit} style={styles.formGrid}>
                        {/* Chaque champ appelle handleChange pour mettre à jour formData */}
                        {[
                            { name:'prenom',    label:'Prénom',           type:'text',     required:true  },
                            { name:'nom',       label:'Nom',              type:'text',     required:true  },
                            { name:'email',     label:'Email',            type:'email',    required:true  },
                            { name:'password',  label:'Mot de passe',     type:'password', required:!editingId },
                            { name:'numero',    label:'N° étudiant',      type:'text',     required:true  },
                            { name:'promotion', label:'Promotion (ex: ING2)', type:'text', required:false },
                            { name:'groupe',    label:'Groupe (ex: A)',   type:'text',     required:false },
                        ].map(f => (
                            <div key={f.name} style={styles.formField}>
                                <label style={styles.label}>{f.label}{f.required && ' *'}</label>
                                <input
                                    name={f.name}
                                    type={f.type}
                                    value={formData[f.name]}
                                    onChange={handleChange}
                                    required={f.required}
                                    placeholder={f.name === 'password' && editingId ? 'Laisser vide pour ne pas changer' : ''}
                                    style={styles.input}
                                />
                            </div>
                        ))}

                        <div style={styles.formActions}>
                            <button type="submit" style={styles.btnPrimary}>
                                {editingId ? 'Enregistrer' : 'Créer'}
                            </button>
                            <button type="button" onClick={() => setShowForm(false)} style={styles.btnSecondary}>
                                Annuler
                            </button>
                        </div>
                    </form>
                </div>
            )}

            {/* Tableau des étudiants */}
            {loading ? <p>Chargement...</p> : (
                <div style={styles.tableContainer}>
                    <table style={styles.table}>
                        <thead>
                            <tr style={styles.thead}>
                                <th style={styles.th}>N° Étudiant</th>
                                <th style={styles.th}>Nom complet</th>
                                <th style={styles.th}>Email</th>
                                <th style={styles.th}>Promotion</th>
                                <th style={styles.th}>Groupe</th>
                                <th style={styles.th}>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {etudiants.map(e => (
                                <tr key={e.id} style={styles.tr}>
                                    <td style={styles.td}><code>{e.numero}</code></td>
                                    <td style={styles.td}>{e.prenom} {e.nom}</td>
                                    <td style={styles.td}>{e.email}</td>
                                    <td style={styles.td}>{e.promotion || '—'}</td>
                                    <td style={styles.td}>{e.groupe || '—'}</td>
                                    <td style={styles.td}>
                                        <button onClick={() => handleEdit(e)} style={styles.btnEdit}>
                                            ✏️ Modifier
                                        </button>
                                        <button onClick={() => handleDelete(e.id, e.nom)} style={styles.btnDelete}>
                                            🗑️ Supprimer
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </Layout>
    );
}

const styles = {
    errorMsg:       { backgroundColor:'#fef2f2', border:'1px solid #fca5a5', color:'#dc2626',
                      padding:'12px', borderRadius:'8px', marginBottom:'16px' },
    successMsg:     { backgroundColor:'#f0fdf4', border:'1px solid #86efac', color:'#16a34a',
                      padding:'12px', borderRadius:'8px', marginBottom:'16px' },
    toolbar:        { display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'20px' },
    count:          { color:'#64748b', margin:0 },
    btnPrimary:     { padding:'10px 20px', backgroundColor:'#3b82f6', color:'white',
                      border:'none', borderRadius:'8px', cursor:'pointer', fontWeight:'500' },
    btnSecondary:   { padding:'10px 20px', backgroundColor:'#f1f5f9', color:'#374151',
                      border:'1px solid #e2e8f0', borderRadius:'8px', cursor:'pointer' },
    formCard:       { backgroundColor:'white', borderRadius:'12px', padding:'24px',
                      marginBottom:'24px', boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    formTitle:      { margin:'0 0 20px', fontSize:'18px', fontWeight:'600' },
    formGrid:       { display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(200px, 1fr))', gap:'16px' },
    formField:      { display:'flex', flexDirection:'column', gap:'6px' },
    label:          { fontSize:'13px', fontWeight:'500', color:'#374151' },
    input:          { padding:'10px', border:'1px solid #d1d5db', borderRadius:'6px', fontSize:'14px' },
    formActions:    { gridColumn:'1 / -1', display:'flex', gap:'12px' },
    tableContainer: { backgroundColor:'white', borderRadius:'12px', overflow:'hidden',
                      boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    table:          { width:'100%', borderCollapse:'collapse' },
    thead:          { backgroundColor:'#f8fafc' },
    th:             { padding:'12px 16px', textAlign:'left', fontSize:'12px',
                      fontWeight:'600', color:'#64748b', textTransform:'uppercase',
                      borderBottom:'1px solid #e2e8f0' },
    tr:             { borderBottom:'1px solid #f1f5f9' },
    td:             { padding:'14px 16px', fontSize:'14px', color:'#374151' },
    btnEdit:        { padding:'6px 12px', backgroundColor:'#eff6ff', color:'#3b82f6',
                      border:'none', borderRadius:'6px', cursor:'pointer', marginRight:'8px', fontSize:'12px' },
    btnDelete:      { padding:'6px 12px', backgroundColor:'#fef2f2', color:'#dc2626',
                      border:'none', borderRadius:'6px', cursor:'pointer', fontSize:'12px' },
};

export default AdminStudents;
