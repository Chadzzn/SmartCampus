// ============================================================
// src/pages/admin/Courses.jsx — Gestion des cours
// Permet de créer, modifier et supprimer les cours.
// Inclut la liste des enseignants pour l'assignation.
// ============================================================

import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import api from '../../api/axios';

function AdminCourses() {
    const [cours,       setCours]       = useState([]);
    const [enseignants, setEnseignants] = useState([]);  // pour le select du formulaire
    const [loading,     setLoading]     = useState(true);
    const [error,       setError]       = useState('');
    const [success,     setSuccess]     = useState('');
    const [showForm,    setShowForm]    = useState(false);
    const [editingId,   setEditingId]   = useState(null);
    const [formData,    setFormData]    = useState({
        code:'', nom:'', description:'', credits:3,
        capacite_max:30, semestre:'', promotion:'', enseignant_id:''
    });

    const fetchData = async () => {
        try {
            // Chargement en parallèle des cours et des enseignants
            const [coursRes, ensRes] = await Promise.all([
                api.get('/courses/getAll.php'),
                api.get('/teachers/getAll.php'),
            ]);
            setCours(coursRes.data);
            setEnseignants(ensRes.data);
        } catch { setError('Erreur de chargement'); }
        finally { setLoading(false); }
    };

    useEffect(() => { fetchData(); }, []);

    const handleChange = (e) => setFormData(p => ({ ...p, [e.target.name]: e.target.value }));

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        try {
            if (editingId) {
                await api.put(`/courses/update.php?id=${editingId}`, formData);
                setSuccess('Cours modifié avec succès');
            } else {
                await api.post('/courses/create.php', formData);
                setSuccess('Cours créé avec succès');
            }
            setShowForm(false);
            fetchData();
        } catch (err) {
            setError(err.response?.data?.error || 'Erreur');
        }
    };

    const handleDelete = async (id, nom) => {
        if (!window.confirm(`Supprimer le cours "${nom}" ?`)) return;
        try {
            await api.delete(`/courses/delete.php?id=${id}`);
            setSuccess('Cours supprimé');
            fetchData();
        } catch (err) {
            setError(err.response?.data?.error || 'Erreur');
        }
    };

    return (
        <Layout title="Gestion des cours">
            {error   && <div style={styles.errorMsg}>{error}</div>}
            {success && <div style={styles.successMsg}>{success}</div>}

            <div style={styles.toolbar}>
                <p style={styles.count}>{cours.length} cours</p>
                <button onClick={() => {
                    setEditingId(null);
                    setFormData({code:'',nom:'',description:'',credits:3,capacite_max:30,semestre:'',promotion:'',enseignant_id:''});
                    setShowForm(true);
                }} style={styles.btnPrimary}>+ Créer un cours</button>
            </div>

            {showForm && (
                <div style={styles.formCard}>
                    <h3 style={styles.formTitle}>{editingId ? 'Modifier' : 'Créer'} un cours</h3>
                    <form onSubmit={handleSubmit} style={styles.formGrid}>
                        <div style={styles.field}>
                            <label style={styles.label}>Code *</label>
                            <input name="code" value={formData.code} onChange={handleChange}
                                   required disabled={!!editingId} style={styles.input} placeholder="ex: WEB201" />
                        </div>
                        <div style={styles.field}>
                            <label style={styles.label}>Nom du cours *</label>
                            <input name="nom" value={formData.nom} onChange={handleChange}
                                   required style={styles.input} />
                        </div>
                        <div style={styles.field}>
                            <label style={styles.label}>Crédits</label>
                            <input name="credits" type="number" value={formData.credits}
                                   onChange={handleChange} min="1" max="10" style={styles.input} />
                        </div>
                        <div style={styles.field}>
                            <label style={styles.label}>Capacité max</label>
                            <input name="capacite_max" type="number" value={formData.capacite_max}
                                   onChange={handleChange} min="1" style={styles.input} />
                        </div>
                        <div style={styles.field}>
                            <label style={styles.label}>Semestre</label>
                            <input name="semestre" value={formData.semestre} onChange={handleChange}
                                   style={styles.input} placeholder="ex: S4" />
                        </div>
                        <div style={styles.field}>
                            <label style={styles.label}>Promotion</label>
                            <input name="promotion" value={formData.promotion} onChange={handleChange}
                                   style={styles.input} placeholder="ex: ING2" />
                        </div>
                        {/* Select pour choisir l'enseignant responsable */}
                        <div style={styles.field}>
                            <label style={styles.label}>Enseignant responsable</label>
                            <select name="enseignant_id" value={formData.enseignant_id}
                                    onChange={handleChange} style={styles.input}>
                                <option value="">— Aucun —</option>
                                {enseignants.map(e => (
                                    <option key={e.id} value={e.id}>{e.prenom} {e.nom}</option>
                                ))}
                            </select>
                        </div>
                        <div style={{...styles.field, gridColumn:'1/-1'}}>
                            <label style={styles.label}>Description</label>
                            <textarea name="description" value={formData.description}
                                      onChange={handleChange} rows={3} style={styles.input} />
                        </div>
                        <div style={{ gridColumn:'1/-1', display:'flex', gap:'12px' }}>
                            <button type="submit" style={styles.btnPrimary}>Enregistrer</button>
                            <button type="button" onClick={() => setShowForm(false)} style={styles.btnSecondary}>Annuler</button>
                        </div>
                    </form>
                </div>
            )}

            {loading ? <p>Chargement...</p> : (
                <div style={styles.grid}>
                    {cours.map(c => (
                        <div key={c.id} style={styles.card}>
                            <div style={styles.cardHeader}>
                                <span style={styles.code}>{c.code}</span>
                                {/* Indicateur de remplissage */}
                                <span style={{
                                    ...styles.badge,
                                    backgroundColor: c.nb_inscrits >= c.capacite_max ? '#fef2f2' : '#f0fdf4',
                                    color: c.nb_inscrits >= c.capacite_max ? '#dc2626' : '#16a34a',
                                }}>
                                    {c.nb_inscrits}/{c.capacite_max}
                                </span>
                            </div>
                            <h3 style={styles.cardTitle}>{c.nom}</h3>
                            <p style={styles.cardMeta}>
                                👨‍🏫 {c.enseignant_nom || 'Non assigné'} · {c.credits} crédits · {c.semestre || '—'}
                            </p>
                            <div style={styles.cardActions}>
                                <button onClick={() => {
                                    setEditingId(c.id);
                                    setFormData({ code:c.code, nom:c.nom, description:c.description||'',
                                                  credits:c.credits, capacite_max:c.capacite_max,
                                                  semestre:c.semestre||'', promotion:c.promotion||'',
                                                  enseignant_id:c.enseignant_id||'' });
                                    setShowForm(true);
                                }} style={styles.btnEdit}>✏️ Modifier</button>
                                <button onClick={() => handleDelete(c.id, c.nom)} style={styles.btnDelete}>🗑️</button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </Layout>
    );
}

const styles = {
    errorMsg:  { backgroundColor:'#fef2f2',border:'1px solid #fca5a5',color:'#dc2626',padding:'12px',borderRadius:'8px',marginBottom:'16px' },
    successMsg:{ backgroundColor:'#f0fdf4',border:'1px solid #86efac',color:'#16a34a',padding:'12px',borderRadius:'8px',marginBottom:'16px' },
    toolbar:   { display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'20px' },
    count:     { color:'#64748b',margin:0 },
    btnPrimary:{ padding:'10px 20px',backgroundColor:'#8b5cf6',color:'white',border:'none',borderRadius:'8px',cursor:'pointer',fontWeight:'500' },
    btnSecondary:{ padding:'10px 20px',backgroundColor:'#f1f5f9',color:'#374151',border:'1px solid #e2e8f0',borderRadius:'8px',cursor:'pointer' },
    formCard:  { backgroundColor:'white',borderRadius:'12px',padding:'24px',marginBottom:'24px',boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    formTitle: { margin:'0 0 20px',fontSize:'18px',fontWeight:'600' },
    formGrid:  { display:'grid',gridTemplateColumns:'repeat(auto-fit, minmax(200px, 1fr))',gap:'16px' },
    field:     { display:'flex',flexDirection:'column',gap:'6px' },
    label:     { fontSize:'13px',fontWeight:'500',color:'#374151' },
    input:     { padding:'10px',border:'1px solid #d1d5db',borderRadius:'6px',fontSize:'14px' },
    grid:      { display:'grid',gridTemplateColumns:'repeat(auto-fill, minmax(280px, 1fr))',gap:'16px' },
    card:      { backgroundColor:'white',borderRadius:'12px',padding:'20px',boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    cardHeader:{ display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'8px' },
    code:      { backgroundColor:'#f3e8ff',color:'#7c3aed',padding:'4px 10px',borderRadius:'6px',fontSize:'12px',fontWeight:'600' },
    badge:     { padding:'4px 10px',borderRadius:'20px',fontSize:'12px',fontWeight:'500' },
    cardTitle: { margin:'0 0 8px',fontSize:'16px',fontWeight:'600',color:'#1e293b' },
    cardMeta:  { color:'#64748b',fontSize:'13px',margin:'0 0 16px' },
    cardActions:{ display:'flex',gap:'8px' },
    btnEdit:   { flex:1,padding:'8px',backgroundColor:'#eff6ff',color:'#3b82f6',border:'none',borderRadius:'6px',cursor:'pointer',fontSize:'13px' },
    btnDelete: { padding:'8px 12px',backgroundColor:'#fef2f2',color:'#dc2626',border:'none',borderRadius:'6px',cursor:'pointer' },
};

export default AdminCourses;
