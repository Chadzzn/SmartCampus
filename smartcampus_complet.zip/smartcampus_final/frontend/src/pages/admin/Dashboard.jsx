// ============================================================
// src/pages/admin/Dashboard.jsx — Tableau de bord Admin
//
// Affiche :
//  - Statistiques générales (nb étudiants, enseignants, cours, séances)
//  - Actions rapides (liens vers les pages de gestion)
//  - Section de verrouillage des notes par cours
// ============================================================

import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import api from '../../api/axios';

function AdminDashboard() {
    // Statistiques affichées dans les cartes du haut
    const [stats, setStats] = useState({
        etudiants: 0, enseignants: 0, cours: 0, seances: 0,
    });
    const [loading,    setLoading]    = useState(true);
    const [allCours,   setAllCours]   = useState([]);   // pour la section verrouillage
    const [lockMsg,    setLockMsg]    = useState('');   // message après verrouillage
    const [lockError,  setLockError]  = useState('');

    // ----------------------------------------------------------------
    // Chargement des statistiques au montage
    // ----------------------------------------------------------------
    useEffect(() => {
        const fetchStats = async () => {
            try {
                // Toutes les requêtes en parallèle pour réduire le temps de chargement
                const [etudiants, enseignants, cours, seances] = await Promise.all([
                    api.get('/students/getAll.php'),
                    api.get('/teachers/getAll.php'),
                    api.get('/courses/getAll.php'),
                    api.get('/schedule/getAll.php'),
                ]);

                setStats({
                    etudiants:   etudiants.data.length,
                    enseignants: enseignants.data.length,
                    cours:       cours.data.length,
                    seances:     seances.data.length,
                });
                // On garde aussi la liste des cours pour la section verrouillage
                setAllCours(cours.data);

            } catch (err) {
                console.error('Erreur chargement statistiques:', err);
            } finally {
                setLoading(false);
            }
        };

        fetchStats();
    }, []);

    // ----------------------------------------------------------------
    // Verrouillage des notes d'un cours (admin uniquement)
    // ----------------------------------------------------------------
    const handleLockNotes = async (coursId, coursNom) => {
        if (!window.confirm(`Verrouiller définitivement les notes du cours "${coursNom}" ?\nAttention : cette action rend les notes non modifiables par les enseignants.`)) return;

        setLockMsg(''); setLockError('');
        try {
            const res = await api.post('/grades/lock.php', { cours_id: coursId });
            setLockMsg(`✅ ${res.data.nb_verrouillees} note(s) verrouillée(s) pour "${coursNom}".`);
        } catch (err) {
            setLockError(err.response?.data?.error || 'Erreur lors du verrouillage');
        }
    };

    // Données des cartes statistiques
    const cards = [
        { label:'Étudiants',   value:stats.etudiants,   icon:'🎓', color:'#3b82f6', path:'/admin/etudiants'   },
        { label:'Enseignants', value:stats.enseignants, icon:'👨‍🏫', color:'#10b981', path:'/admin/enseignants' },
        { label:'Cours',       value:stats.cours,       icon:'📚', color:'#8b5cf6', path:'/admin/cours'       },
        { label:'Séances',     value:stats.seances,     icon:'📅', color:'#f59e0b', path:'/admin/emploi-temps'},
    ];

    return (
        <Layout title="Tableau de bord — Administration">
            {loading ? (
                <p style={{ color:'#94a3b8' }}>Chargement des statistiques...</p>
            ) : (<>

                {/* ---- Cartes statistiques ---- */}
                <div style={styles.grid}>
                    {cards.map(card => (
                        <div
                            key={card.label}
                            style={{ ...styles.card, borderTop: `4px solid ${card.color}` }}
                            onClick={() => window.location.href = card.path}
                        >
                            <div style={styles.cardIcon}>{card.icon}</div>
                            <div>
                                <div style={{ ...styles.cardValue, color: card.color }}>
                                    {card.value}
                                </div>
                                <div style={styles.cardLabel}>{card.label}</div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* ---- Actions rapides ---- */}
                <div style={styles.section}>
                    <h2 style={styles.sectionTitle}>⚡ Actions rapides</h2>
                    <div style={styles.actionsGrid}>
                        {[
                            { href:'/admin/etudiants',    label:'+ Ajouter un étudiant',   color:'#3b82f6' },
                            { href:'/admin/enseignants',  label:'+ Ajouter un enseignant', color:'#10b981' },
                            { href:'/admin/cours',        label:'+ Créer un cours',         color:'#8b5cf6' },
                            { href:'/admin/emploi-temps', label:'+ Planifier une séance',  color:'#f59e0b' },
                        ].map(a => (
                            <a
                                key={a.href}
                                href={a.href}
                                style={{ ...styles.actionBtn, backgroundColor: a.color }}
                            >
                                {a.label}
                            </a>
                        ))}
                    </div>
                </div>

                {/* ---- Verrouillage des notes ---- */}
                <div style={styles.section}>
                    <h2 style={styles.sectionTitle}>🔒 Verrouillage des notes</h2>
                    <p style={styles.sectionDesc}>
                        Une fois verrouillées, les notes d'un cours ne peuvent plus être modifiées
                        par les enseignants. Cette action est généralement effectuée en fin de semestre.
                    </p>

                    {lockMsg   && <div style={styles.successMsg}>{lockMsg}</div>}
                    {lockError && <div style={styles.errorMsg}>{lockError}</div>}

                    <div style={styles.lockGrid}>
                        {allCours.map(c => (
                            <div key={c.id} style={styles.lockCard}>
                                <div>
                                    <span style={styles.lockCode}>{c.code}</span>
                                    <span style={styles.lockNom}>{c.nom}</span>
                                </div>
                                <button
                                    onClick={() => handleLockNotes(c.id, c.nom)}
                                    style={styles.lockBtn}
                                    title={`Verrouiller les notes de ${c.nom}`}
                                >
                                    🔒 Verrouiller
                                </button>
                            </div>
                        ))}
                    </div>
                </div>

            </>)}
        </Layout>
    );
}

const styles = {
    grid:         { display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(180px, 1fr))', gap:'16px', marginBottom:'24px' },
    card:         { backgroundColor:'white', borderRadius:'12px', padding:'22px', cursor:'pointer', display:'flex', alignItems:'center', gap:'14px', boxShadow:'0 1px 3px rgba(0,0,0,0.1)', transition:'transform 0.15s' },
    cardIcon:     { fontSize:'34px' },
    cardValue:    { fontSize:'30px', fontWeight:'bold' },
    cardLabel:    { color:'#64748b', fontSize:'13px', marginTop:'2px' },

    section:      { backgroundColor:'white', borderRadius:'12px', padding:'24px', marginBottom:'20px', boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    sectionTitle: { margin:'0 0 8px', fontSize:'17px', fontWeight:'600', color:'#1e293b' },
    sectionDesc:  { color:'#64748b', fontSize:'13px', margin:'0 0 16px', lineHeight:'1.5' },
    actionsGrid:  { display:'flex', gap:'12px', flexWrap:'wrap' },
    actionBtn:    { padding:'11px 18px', color:'white', textDecoration:'none', borderRadius:'8px', fontWeight:'500', fontSize:'14px' },

    successMsg:   { backgroundColor:'#f0fdf4', border:'1px solid #86efac', color:'#15803d', padding:'10px 14px', borderRadius:'8px', marginBottom:'12px', fontSize:'14px' },
    errorMsg:     { backgroundColor:'#fef2f2', border:'1px solid #fca5a5', color:'#dc2626', padding:'10px 14px', borderRadius:'8px', marginBottom:'12px', fontSize:'14px' },

    lockGrid:     { display:'flex', flexDirection:'column', gap:'8px' },
    lockCard:     { display:'flex', justifyContent:'space-between', alignItems:'center', padding:'12px 16px', border:'1px solid #e2e8f0', borderRadius:'8px', backgroundColor:'#f8fafc' },
    lockCode:     { backgroundColor:'#eff6ff', color:'#2563eb', padding:'2px 7px', borderRadius:'4px', fontSize:'12px', fontWeight:'600', marginRight:'10px' },
    lockNom:      { fontSize:'14px', color:'#374151', fontWeight:'500' },
    lockBtn:      { padding:'7px 14px', backgroundColor:'white', color:'#dc2626', border:'1px solid #fecaca', borderRadius:'7px', cursor:'pointer', fontSize:'13px', fontWeight:'500', whiteSpace:'nowrap' },
};

export default AdminDashboard;
