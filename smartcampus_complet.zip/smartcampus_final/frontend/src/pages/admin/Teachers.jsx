// ============================================================
// src/pages/admin/Teachers.jsx — Gestion des enseignants
// Même structure que Students.jsx (CRUD complet)
// ============================================================

import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import api from '../../api/axios';

function AdminTeachers() {
    const [enseignants, setEnseignants] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error,   setError]   = useState('');
    const [success, setSuccess] = useState('');
    const [showForm,  setShowForm]  = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [formData,  setFormData]  = useState({
        nom:'', prenom:'', email:'', password:'', specialite:'', bureau:''
    });

    const fetchEnseignants = async () => {
        try {
            const res = await api.get('/teachers/getAll.php');
            setEnseignants(res.data);
        } catch { setError('Erreur de chargement'); }
        finally { setLoading(false); }
    };

    useEffect(() => { fetchEnseignants(); }, []);

    const handleChange = (e) => setFormData(p => ({ ...p, [e.target.name]: e.target.value }));

    const handleEdit = (e) => {
        setEditingId(e.id);
        setFormData({ nom:e.nom, prenom:e.prenom, email:e.email, password:'',
                      specialite:e.specialite||'', bureau:e.bureau||'' });
        setShowForm(true);
    };

    const handleSubmit = async (ev) => {
        ev.preventDefault();
        setError('');
        try {
            if (editingId) {
                await api.put(`/teachers/update.php?id=${editingId}`, formData);
                setSuccess('Enseignant modifié');
            } else {
                await api.post('/teachers/create.php', formData);
                setSuccess('Enseignant créé');
            }
            setShowForm(false);
            fetchEnseignants();
        } catch (err) {
            setError(err.response?.data?.error || 'Erreur');
        }
    };

    return (
        <Layout title="Gestion des enseignants">
            {error   && <div style={styles.errorMsg}>{error}</div>}
            {success && <div style={styles.successMsg}>{success}</div>}

            <div style={styles.toolbar}>
                <p style={styles.count}>{enseignants.length} enseignant(s)</p>
                <button onClick={() => { setEditingId(null); setFormData({nom:'',prenom:'',email:'',password:'',specialite:'',bureau:''}); setShowForm(true); }} style={styles.btnPrimary}>
                    + Ajouter un enseignant
                </button>
            </div>

            {showForm && (
                <div style={styles.formCard}>
                    <h3 style={styles.formTitle}>{editingId ? 'Modifier' : 'Ajouter'} un enseignant</h3>
                    <form onSubmit={handleSubmit} style={styles.formGrid}>
                        {[
                            { name:'prenom',    label:'Prénom',       type:'text',     req:true },
                            { name:'nom',       label:'Nom',          type:'text',     req:true },
                            { name:'email',     label:'Email',        type:'email',    req:true },
                            { name:'password',  label:'Mot de passe', type:'password', req:!editingId },
                            { name:'specialite',label:'Spécialité',   type:'text',     req:false },
                            { name:'bureau',    label:'Bureau',       type:'text',     req:false },
                        ].map(f => (
                            <div key={f.name} style={styles.field}>
                                <label style={styles.label}>{f.label}</label>
                                <input name={f.name} type={f.type} value={formData[f.name]}
                                       onChange={handleChange} required={f.req} style={styles.input} />
                            </div>
                        ))}
                        <div style={{ gridColumn:'1/-1', display:'flex', gap:'12px' }}>
                            <button type="submit" style={styles.btnPrimary}>Enregistrer</button>
                            <button type="button" onClick={() => setShowForm(false)} style={styles.btnSecondary}>Annuler</button>
                        </div>
                    </form>
                </div>
            )}

            {loading ? <p>Chargement...</p> : (
                <div style={styles.tableContainer}>
                    <table style={styles.table}>
                        <thead>
                            <tr style={styles.thead}>
                                {['Nom complet','Email','Spécialité','Bureau','Cours','Actions'].map(h => (
                                    <th key={h} style={styles.th}>{h}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {enseignants.map(e => (
                                <tr key={e.id} style={styles.tr}>
                                    <td style={styles.td}>{e.prenom} {e.nom}</td>
                                    <td style={styles.td}>{e.email}</td>
                                    <td style={styles.td}>{e.specialite || '—'}</td>
                                    <td style={styles.td}>{e.bureau || '—'}</td>
                                    <td style={styles.td}>
                                        <span style={styles.badge}>{e.nb_cours} cours</span>
                                    </td>
                                    <td style={styles.td}>
                                        <button onClick={() => handleEdit(e)} style={styles.btnEdit}>✏️ Modifier</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </Layout>
    );
}

const styles = {
    errorMsg:      { backgroundColor:'#fef2f2',border:'1px solid #fca5a5',color:'#dc2626',padding:'12px',borderRadius:'8px',marginBottom:'16px' },
    successMsg:    { backgroundColor:'#f0fdf4',border:'1px solid #86efac',color:'#16a34a',padding:'12px',borderRadius:'8px',marginBottom:'16px' },
    toolbar:       { display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'20px' },
    count:         { color:'#64748b',margin:0 },
    btnPrimary:    { padding:'10px 20px',backgroundColor:'#10b981',color:'white',border:'none',borderRadius:'8px',cursor:'pointer',fontWeight:'500' },
    btnSecondary:  { padding:'10px 20px',backgroundColor:'#f1f5f9',color:'#374151',border:'1px solid #e2e8f0',borderRadius:'8px',cursor:'pointer' },
    formCard:      { backgroundColor:'white',borderRadius:'12px',padding:'24px',marginBottom:'24px',boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    formTitle:     { margin:'0 0 20px',fontSize:'18px',fontWeight:'600' },
    formGrid:      { display:'grid',gridTemplateColumns:'repeat(auto-fit, minmax(200px, 1fr))',gap:'16px' },
    field:         { display:'flex',flexDirection:'column',gap:'6px' },
    label:         { fontSize:'13px',fontWeight:'500',color:'#374151' },
    input:         { padding:'10px',border:'1px solid #d1d5db',borderRadius:'6px',fontSize:'14px' },
    tableContainer:{ backgroundColor:'white',borderRadius:'12px',overflow:'hidden',boxShadow:'0 1px 3px rgba(0,0,0,0.1)' },
    table:         { width:'100%',borderCollapse:'collapse' },
    thead:         { backgroundColor:'#f8fafc' },
    th:            { padding:'12px 16px',textAlign:'left',fontSize:'12px',fontWeight:'600',color:'#64748b',textTransform:'uppercase',borderBottom:'1px solid #e2e8f0' },
    tr:            { borderBottom:'1px solid #f1f5f9' },
    td:            { padding:'14px 16px',fontSize:'14px',color:'#374151' },
    badge:         { padding:'4px 10px',backgroundColor:'#eff6ff',color:'#3b82f6',borderRadius:'20px',fontSize:'12px' },
    btnEdit:       { padding:'6px 12px',backgroundColor:'#eff6ff',color:'#3b82f6',border:'none',borderRadius:'6px',cursor:'pointer',fontSize:'12px' },
};

export default AdminTeachers;
