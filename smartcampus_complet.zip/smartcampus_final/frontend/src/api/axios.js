// ============================================================
// src/api/axios.js — Configuration d'Axios
// On envoie le rôle et l'ID de l'utilisateur dans chaque requête
// via des headers personnalisés, car les cookies de session PHP
// ne fonctionnent pas facilement en cross-origin avec MAMP.
// ============================================================

import axios from 'axios';

const api = axios.create({
    // URL directe vers le backend MAMP
    baseURL: 'http://localhost/smartcampus/backend/api',
    withCredentials: false,
    headers: {
        'Content-Type': 'application/json',
    },
});

// --- Intercepteur de REQUÊTE ---
// Avant chaque requête, on ajoute les infos de l'utilisateur connecté
// depuis localStorage dans les headers.
api.interceptors.request.use((config) => {
    const saved = localStorage.getItem('sc_user');
    if (saved) {
        const user = JSON.parse(saved);
        // On envoie le rôle et l'ID pour que PHP puisse vérifier les droits
        config.headers['X-User-Role'] = user.role;
        config.headers['X-User-Id']   = user.id;
    }
    return config;
});

// --- Intercepteur de RÉPONSE ---
api.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response?.status === 401) {
            localStorage.removeItem('sc_user');
            window.location.href = '/login';
        }
        return Promise.reject(error);
    }
);

export default api;
