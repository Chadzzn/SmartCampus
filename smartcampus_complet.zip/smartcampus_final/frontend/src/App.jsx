// ============================================================
// src/App.jsx — Fichier principal de l'application React
// Définit toutes les routes de l'application.
// React Router permet de naviguer entre les pages sans recharger la page.
// ============================================================

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';

// Import des pages
import Login from './pages/Login';

// Pages Admin
import AdminDashboard    from './pages/admin/Dashboard';
import AdminStudents     from './pages/admin/Students';
import AdminTeachers     from './pages/admin/Teachers';
import AdminCourses      from './pages/admin/Courses';

// Pages Enseignant
import TeacherDashboard  from './pages/teacher/Dashboard';
import TeacherCourses    from './pages/teacher/MyCourses';
import TeacherGrades     from './pages/teacher/Grades';

// Pages Étudiant
import StudentDashboard  from './pages/student/Dashboard';
import StudentCourses    from './pages/student/MyCourses';
import StudentGrades     from './pages/student/MyGrades';

// Page commune : Emploi du temps
import Schedule          from './pages/Schedule';

function App() {
    return (
        // AuthProvider donne accès au contexte d'auth dans toute l'app
        <AuthProvider>
            <BrowserRouter>
                <Routes>
                    {/* Page publique : connexion */}
                    <Route path="/login" element={<Login />} />

                    {/* Redirection automatique de / vers /login */}
                    <Route path="/" element={<Navigate to="/login" replace />} />

                    {/* ---------------------------------------- */}
                    {/* Routes ADMIN — protégées, rôle "admin" */}
                    {/* ---------------------------------------- */}
                    <Route path="/admin" element={
                        <ProtectedRoute roles={['admin']}>
                            <AdminDashboard />
                        </ProtectedRoute>
                    } />
                    <Route path="/admin/etudiants" element={
                        <ProtectedRoute roles={['admin']}>
                            <AdminStudents />
                        </ProtectedRoute>
                    } />
                    <Route path="/admin/enseignants" element={
                        <ProtectedRoute roles={['admin']}>
                            <AdminTeachers />
                        </ProtectedRoute>
                    } />
                    <Route path="/admin/cours" element={
                        <ProtectedRoute roles={['admin']}>
                            <AdminCourses />
                        </ProtectedRoute>
                    } />
                    <Route path="/admin/emploi-temps" element={
                        <ProtectedRoute roles={['admin']}>
                            <Schedule />
                        </ProtectedRoute>
                    } />

                    {/* ---------------------------------------- */}
                    {/* Routes ENSEIGNANT */}
                    {/* ---------------------------------------- */}
                    <Route path="/enseignant" element={
                        <ProtectedRoute roles={['enseignant']}>
                            <TeacherDashboard />
                        </ProtectedRoute>
                    } />
                    <Route path="/enseignant/mes-cours" element={
                        <ProtectedRoute roles={['enseignant']}>
                            <TeacherCourses />
                        </ProtectedRoute>
                    } />
                    <Route path="/enseignant/notes" element={
                        <ProtectedRoute roles={['enseignant']}>
                            <TeacherGrades />
                        </ProtectedRoute>
                    } />
                    <Route path="/enseignant/emploi-temps" element={
                        <ProtectedRoute roles={['enseignant']}>
                            <Schedule />
                        </ProtectedRoute>
                    } />

                    {/* ---------------------------------------- */}
                    {/* Routes ÉTUDIANT */}
                    {/* ---------------------------------------- */}
                    <Route path="/etudiant" element={
                        <ProtectedRoute roles={['etudiant']}>
                            <StudentDashboard />
                        </ProtectedRoute>
                    } />
                    <Route path="/etudiant/mes-cours" element={
                        <ProtectedRoute roles={['etudiant']}>
                            <StudentCourses />
                        </ProtectedRoute>
                    } />
                    <Route path="/etudiant/mes-notes" element={
                        <ProtectedRoute roles={['etudiant']}>
                            <StudentGrades />
                        </ProtectedRoute>
                    } />
                    <Route path="/etudiant/emploi-temps" element={
                        <ProtectedRoute roles={['etudiant']}>
                            <Schedule />
                        </ProtectedRoute>
                    } />

                    {/* Route 404 : page inconnue → retour à l'accueil */}
                    <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
            </BrowserRouter>
        </AuthProvider>
    );
}

export default App;
