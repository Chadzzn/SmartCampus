import { createContext, useState, useContext } from 'react';
import api from '../api/axios';

export const AuthContext = createContext(null);

export function AuthProvider({ children }) {
    // On récupère l'user depuis localStorage s'il existe déjà
    const [user, setUser] = useState(() => {
        const saved = localStorage.getItem('sc_user');
        return saved ? JSON.parse(saved) : null;
    });

    const login = async (email, password) => {
        const res = await api.post('/auth/login.php', { email, password });
        const u = res.data.user;
        setUser(u);
        // On sauvegarde l'user dans localStorage pour survivre au refresh
        localStorage.setItem('sc_user', JSON.stringify(u));
        return u;
    };

    const logout = async () => {
        try { await api.post('/auth/logout.php'); } catch {}
        setUser(null);
        localStorage.removeItem('sc_user');
        window.location.href = '/login';
    };

    return (
        <AuthContext.Provider value={{ user, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    return useContext(AuthContext);
}