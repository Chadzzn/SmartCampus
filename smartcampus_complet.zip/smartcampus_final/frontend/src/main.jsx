// ============================================================
// src/main.jsx — Point d'entrée de l'application React
// Ce fichier monte l'application React dans le DOM (index.html).
// C'est le tout premier fichier JS exécuté.
// ============================================================

import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';

// Styles globaux minimaux
const globalStyle = document.createElement('style');
globalStyle.textContent = `
  /* Réinitialisation de base */
  *, *::before, *::after { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    background-color: #f1f5f9;
    color: #1e293b;
  }
  /* Scrollbar personnalisée */
  ::-webkit-scrollbar { width: 6px; }
  ::-webkit-scrollbar-track { background: #f1f5f9; }
  ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }
`;
document.head.appendChild(globalStyle);

// createRoot monte React dans la div#root de index.html
createRoot(document.getElementById('root')).render(
    // StrictMode active des avertissements supplémentaires en développement
    <StrictMode>
        <App />
    </StrictMode>
);
